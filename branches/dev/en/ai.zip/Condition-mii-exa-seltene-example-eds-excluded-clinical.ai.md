# Ehlers-Danlos-Syndrom - Ausgeschlossen - MII IG Kerndatensatz-Modul Seltene Erkrankungen v2027.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Ehlers-Danlos-Syndrom - Ausgeschlossen**

## Example Condition: Ehlers-Danlos-Syndrom - Ausgeschlossen

-------

**English**

-------

Profile: [MII PR SE Clinical Diagnosis](StructureDefinition-mii-pr-seltene-clinical-diagnosis.md) version: 2027.0.0-ballot

**Condition Asserted Date**: 2024-11-20

**clinicalStatus**: Inactive

**verificationStatus**: Refuted

**category**: Encounter Diagnosis

**code**: Ehlers-Danlos-Syndrom (ausgeschlossen)

**subject**: [Max Mustermann (official) Male, DoB: 1990-01-01 ( http://test-krankenhaus.de/fhir/sid/patienten#12345)](Patient-mii-exa-seltene-patient.md)

**abatement**: 2024-11-20

**recordedDate**: 2024-11-20

### Evidences

| | | |
| :--- | :--- | :--- |
| - | **Code** | **Detail** |
| * | Beighton-Score niedrig | [Observation Joint hypermobility](Observation-mii-exa-seltene-beighton-score-low.md) |

**note**: 

> 

EDS als Differentialdiagnose ausgeschlossen. Beighton-Score 2/9, keine Hauthyperextensibilität, keine atrophen Narben.




## Resource Content

```json
{
  "resourceType" : "Condition",
  "id" : "mii-exa-seltene-example-eds-excluded-clinical",
  "meta" : {
    "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-clinical-diagnosis|2027.0.0-ballot"]
  },
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/condition-assertedDate",
    "valueDateTime" : "2024-11-20"
  }],
  "clinicalStatus" : {
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/condition-clinical",
      "code" : "inactive"
    }]
  },
  "verificationStatus" : {
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/condition-ver-status",
      "code" : "refuted"
    }]
  },
  "category" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/condition-category",
      "code" : "encounter-diagnosis"
    }]
  }],
  "code" : {
    "coding" : [{
      "system" : "http://fhir.de/CodeSystem/bfarm/icd-10-gm",
      "version" : "2024",
      "code" : "Q79.6",
      "display" : "Ehlers-Danlos-Syndrom"
    },
    {
      "system" : "http://www.orpha.net",
      "code" : "98249",
      "display" : "Ehlers-Danlos syndrome"
    }],
    "text" : "Ehlers-Danlos-Syndrom (ausgeschlossen)"
  },
  "subject" : {
    "reference" : "Patient/mii-exa-seltene-patient"
  },
  "abatementDateTime" : "2024-11-20",
  "recordedDate" : "2024-11-20",
  "evidence" : [{
    "code" : [{
      "text" : "Beighton-Score niedrig"
    }],
    "detail" : [{
      "reference" : "Observation/mii-exa-seltene-beighton-score-low"
    }]
  }],
  "note" : [{
    "text" : "EDS als Differentialdiagnose ausgeschlossen. Beighton-Score 2/9, keine Hauthyperextensibilität, keine atrophen Narben."
  }]
}

```
