# Newborn Screening - MII IG Kerndatensatz-Modul Seltene Erkrankungen v2027.0.0-ballot.rc1

* [**Table of Contents**](toc.md)
* [**Guidance**](guidance.md)
* **Newborn Screening**

## Newborn Screening

Newborn screening is where a rare disease is most often found first. In Germany it is the one population-wide programme that systematically detects rare conditions before symptoms appear — which makes its results a natural starting point for the patient journeys this module describes.

> **What this page is, and what it is not.** This module does **not** specify newborn screening. The [module description](index.md) names a dedicated KDS module for newborn screening as a sensible future addition, and this page is groundwork for it: a terminology handout that pins down which codes exist, which do not, and how a screening result would be represented if a project needs it today. Nothing here is normative for this module, and no profile in this module requires it.

### The target conditions

The G-BA Kinder-Richtlinie (version of 15 May 2025, in force since 1 January 2026) lists **20 target conditions** in § 17 (1). Screening for cystic fibrosis is a legally separate programme under 23 ff. and is listed separately below. Since May 2026 the list includes vitamin B12 deficiency, homocystinuria, propionic acidemia and methylmalonic aciduria — four additions that older overviews of "the German newborn screening" do not have.

Each condition is detected through a **lead analyte**. The assignment is not one-to-one in either direction: propionylcarnitine (C3) is the lead analyte for three conditions at once, while the single condition "carnitine cycle defects" needs three analytes. That is why the corresponding ValueSet holds 21 codes rather than 21 conditions.

| | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- |
| 1 | Congenital hypothyroidism | TSH | `29575-8` | 442 | E03.1 |
| 2 | Congenital adrenal hyperplasia (CAH) | 17-OH-progesterone | `38473-5` | 418 | E25.0 |
| 3 | Biotinidase deficiency | biotinidase activity | `75217-0` | 79241 | E53.8 |
| 4 | Galactosemia | total galactose | `54084-9` | 79239 | E74.2 |
| 5 | Phenylketonuria / hyperphenylalaninemia | phenylalanine | `29573-3` | 716 | E70.0 / E70.1 |
| 6 | Maple syrup urine disease | leucine | `47679-6` | 511 | E71.0 |
| 7 | MCAD deficiency | octanoylcarnitine (C8) | `53175-6` | 42 | E71.3 |
| 8 | LCHAD deficiency | C16-OH | `50125-4` | 5 | E71.3 |
| 9 | VLCAD deficiency | C14:1 | `53191-3` | 26793 | E71.3 |
| 10a | Carnitine cycle defects — CPT-I | free carnitine (C0) | `38481-8` | 156 | E71.3 |
| 10b | Carnitine cycle defects — CPT-II | palmitoylcarnitine (C16) | `53199-6` | 157 | E71.3 |
| 10c | Carnitine cycle defects — CACT | C0/(C16+C18) | `53235-8` | 159 | E71.3 |
| 11 | Glutaric aciduria type I | glutarylcarnitine (C5-DC) | `45207-8` | 25 | E72.3 |
| 12 | Isovaleric acidemia | isovalerylcarnitine (C5) | `42920-9` | 33 | E71.1 |
| 13 | Tyrosinemia type I | succinylacetone | `53231-7` | 882 | E70.2 |
| 14 | Severe combined immunodeficiency (SCID) | TREC | `62320-7` | 183660 | D81.0 / D81.1 / D81.2 |
| 15 | Sickle cell disease | haemoglobinopathy screening panel | `54081-5` | 232 | D57.0 / D57.1 |
| 16 | Spinal muscular atrophy (5q) | SMN1 (PCR) | `92002-5` | 70 | G12.0 / G12.1 |
| 17 | Vitamin B12 deficiency | propionylcarnitine (C3) | `53160-8` | — see**limits** | E53.8 / D51.9 |
| 18 | Homocystinuria | methionine | `47700-0` | 394 | E72.1 |
| 19 | Propionic acidemia | propionylcarnitine (C3) | `53160-8` | 35 | E71.1 |
| 20 | Methylmalonic aciduria | propionylcarnitine (C3) | `53160-8` | 27 | E71.1 |
| § 23 | Cystic fibrosis (separate programme) | IRT | `48633-2` | 586 | E84.0 / E84.9 |

ICD-10-GM is coarser than the programme: E71.3 covers MCAD, LCHAD, VLCAD **and** all three carnitine cycle defects, and E71.1 covers isovaleric acidemia, propionic acidemia and methylmalonic aciduria together. Only ORPHA separates them — which is precisely the argument this module makes for ORPHAcodes throughout.

### The ValueSets, and where they come from

Six ValueSets ship with this module. Five of them are **generated from the LOINC-SNOMED ontology**, one is **curated from the Richtlinie**. The difference matters for anyone who wants to trust or extend them.

| | | |
| :--- | :--- | :--- |
| [NBS lead analytes](ValueSet-mii-vs-seltene-nbs-target-analyte.md) | 21 | curated: § 17 (1) and 23 ff. of the Richtlinie |
| [Acylcarnitines in DBS](ValueSet-mii-vs-seltene-nbs-acylcarnitine-dbs.md) | 78 | ECL over the ontology |
| [Amino acids in DBS](ValueSet-mii-vs-seltene-nbs-aminoacid-dbs.md) | 96 | ECL over the ontology |
| [Enzyme activities in DBS](ValueSet-mii-vs-seltene-nbs-enzyme-activity-dbs.md) | 34 | ECL over the ontology |
| [Ratios in DBS](ValueSet-mii-vs-seltene-nbs-ratio-dbs.md) | 47 | ECL over the ontology |
| [Haemoglobin fractions in DBS](ValueSet-mii-vs-seltene-nbs-hemoglobin-dbs.md) | 9 | ECL over the ontology |
| [All DBS analytes](ValueSet-mii-vs-seltene-nbs-dbs-all.md) | 608 | intensional over LOINC's`SYSTEM`property |

The generated five start from one expression describing "anything measured in a dried blood spot":

```
< 363787002 |Observable entity| :
    704327008 |Direct site| = 440500007 |Dried blood spot specimen|

```

which the LOINC-SNOMED edition answers with 335 concepts. Each ValueSet then narrows that set along one axis of the ontology — by component (`<< 102651000 |Acylcarnitine|`, `<< 52518006 |Amino acid|`, `<< 38082009 |Haemoglobin|`) or by property (`118524006 |Catalytic concentration|`, `118563004 |Substance ratio|`). Membership is therefore a fact about the ontology, not an editorial choice, and `scripts/generate-nbs-valuesets.py --check` re-derives the files and fails if they have drifted.

**Why the ValueSets contain LOINC codes even though the query runs against SNOMED.** Every LOINC-SNOMED concept carries its LOINC code as an `alternateIdentifier`, so the ontology can select the concepts while LOINC supplies the codes. That indirection is deliberate: tx.fhir.org — the terminology server this IG builds and validates against — does not know the LOINC-SNOMED edition, so an intensional ECL ValueSet would not expand at all. All 264 codes were confirmed individually with `CodeSystem/$lookup` before being written.

The generated ValueSets describe **what can be measured in a dried blood spot**, not what the German programme measures. They therefore also contain analytes that are not part of it — the lysosomal enzymes of conditions screened elsewhere, and a few analytes used for entirely different purposes. Use the curated lead-analyte ValueSet when you mean the German programme.

**And they are not complete against LOINC — grouping costs coverage.** The LOINC-SNOMED edition only covers the part of LOINC that has been mapped to SNOMED: 335 concepts, against **608 LOINC codes** whose `SYSTEM` is a dried blood spot. Roughly 45 % of the LOINC codes are therefore absent from the ontology, and the missing ones are not exotic — `50086-8` (C5-OH, the lead metabolite for 3-MCC deficiency) and `53166-5` (C4) are among them, as are most of the diagnostic ratios built from them. Measured per group: acylcarnitines cover about half of LOINC's dried-blood-spot acylcarnitine codes, haemoglobin fractions about a third.

That is why a sixth ValueSet exists. [All DBS analytes](ValueSet-mii-vs-seltene-nbs-dbs-all.md) binds intensionally to LOINC's own `SYSTEM` property (`LP21304-8`), so it is complete by construction and does not age — a new dried-blood-spot code from LOINC is in it without anyone touching a file. What it cannot offer is the clinical grouping: analytes, ratios, panels, interpretation codes and unrelated assays (drug levels, serology, PSA) all sit side by side. **Use the grouped sets when you need a clinically bounded list, the complete one when you need coverage.**

### Representing a result

A single measurement is an `Observation`. The LOINC analyte code already carries both the specimen (DBS) and the property, so the code alone answers "what was measured, in what, and as what kind of quantity":

* `code` — the analyte code from the table above
* `value[x]` — `valueQuantity` in µmol/L (UCUM `umol/L`) for the `[Moles/volume]` codes; a unitless `valueQuantity` (UCUM `1`) for ratios; a `valueCodeableConcept` for `[Presence]` codes
* `interpretation` — for screening, the LOINC LA answer codes are more precise than the generic HL7 interpretation codes: `LA18592-8` **In range**, `LA18593-6` **Out of range**
* `category` — `laboratory`
* `specimen` — a `Specimen` of type SNOMED `440500007` **Dried blood spot specimen**

A complete report nests three levels: the report panel `57128-1`, an overall interpretation `57130-7` (answered with codes such as `LA12428-1` **All screening is in range for the conditions tested** or `LA18944-1` **Screen is out of range for at least one condition**), and per-condition interpretations that sit between the panel and the individual analytes.

```
57128-1  Newborn Screening Report summary panel
 ├─ hasMember → 57130-7  overall interpretation        → LA12428-1 / LA18944-1 …
 ├─ hasMember → 46752-2  MCAD/GA-2 interpretation      → LA18592-8 / LA18593-6
 │    └─ derivedFrom → 53175-6  C8       (valueQuantity µmol/L)
 │    └─ derivedFrom → 53177-2  C8/C10   (valueQuantity 1)
 └─ hasMember → 46762-1  hypothyroidism interpretation → LA18592-8 …
      └─ derivedFrom → 29575-8  TSH      (valueQuantity)

```

Where a screening result leads to a diagnosis, that diagnosis belongs in this module's own profiles — a suspicion from screening is a [clinical diagnosis](StructureDefinition-mii-pr-seltene-clinical-diagnosis.md) with `verificationStatus = unconfirmed`, and its genetic confirmation is a [genetic diagnosis](StructureDefinition-mii-pr-seltene-genetic-diagnosis.md). The [SMA case example](sma-example-annotations.md) walks exactly that path, from a positive newborn screen to molecular confirmation.

### Limits — what LOINC does not offer

The table below lists the codes this module looked for and did **not** find. Each entry was checked against LOINC directly, rather than inferred — so "missing" means searched-for and absent, not merely unknown to us.

Why this matters: wherever a code is missing, an implementer needs one anyway and will invent a local one. Naming the gaps here means the same gap gets the same workaround across sites, instead of a different private code in each.

| | | |
| :--- | :--- | :--- |
| 3-OH-propionic acid in DBS | second-tier parameter for conditions 17–20 | only plasma (`47536-8`), urine (`29625-1`), CSF, amniotic fluid — no DBS code |
| PAP (pancreatitis-associated protein) | second tier of the CF programme | no LOINC code at all, in any specimen |
| Vitamin B12 deficiency interpretation | condition 17 | none among the newborn-screen interpretation codes. The closest,`46747-2`**Propionic/Methylmalonic Acidemias**, is itself DISCOURAGED; the active fallback is the group code`46744-9`**Organic acidemias**, which is broader still |
| SMN1 deletion in DBS | condition 16, where the Richtlinie asks for homozygous SMN1 deletion | only`92002-5`, a cycle-threshold value — not a deletion finding |
| Acylcarnitine / amino acid**panel**for DBS | a collective code for the MS/MS profile | panel codes exist only for serum, plasma and urine; for DBS there are single-analyte codes only |
| ORPHA for "vitamin B12 deficiency" | condition 17 | no code matches the Richtlinie's broad term, which also covers acquired maternal deficiency |

**LOINC has retired most of the per-condition interpretation codes.** A second verification pass over the whole code set found **18 DISCOURAGED codes**, and for eight of them there is no active condition-specific successor — only group codes such as `46736-5` **Fatty acid oxidation defects**, `46744-9` **Organic acidemias** and `46733-2` **Amino acidemias**. That affects LCHAD, VLCAD, CPT2/CACT, glutaric aciduria I, propionic and methylmalonic acidemia, homocystinuria and tyrosinemia. Anyone who wants to keep naming the individual condition has to carry the specificity elsewhere — through the group code on `Observation.code` **plus** a link to the `Condition`, or through the underlying analyte observations. Two codes that still look like obvious successors, `46766-2` and `46767-0`, are DISCOURAGED themselves.

The same pass established that the sickle cell screen has changed shape rather than merely changed code: the three method-specific "haemoglobin pattern" codes (`54104-5`, `54103-7`, `54105-2`) are all DISCOURAGED, and LOINC now models the finding as a ranking of the haemoglobins actually detected (`64117-5` **Most predominant hemoglobin in DBS** and its siblings) plus a suspicion code (`71592-0`). The table above uses the screening panel code `54081-5`; a project that needs the finding itself, not the fact that screening happened, should use `64117-5`.

**One code was caught by the build, not by the research.** `54104-5` **Hemoglobin pattern in DBS by HPLC** resolves perfectly well and looks like the obvious lead analyte for sickle cell disease — but LOINC gives it the status **DISCOURAGED**, which the IG Publisher reported once the ValueSet existed. It has been replaced with the panel code `54081-5` (ACTIVE); the specific finding for sickle cell disease is the HbS fraction `56476-5`, which the generated haemoglobin ValueSet contains. The generator now reads the LOINC `STATUS` property alongside the display, so a discouraged or deprecated code is reported rather than silently published.

One methodological caveat: the display texts come from tx.fhir.org, which does not expose LOINC's `LONG_COMMON_NAME` as a separate property. They are the server's `display` values — the ones a FHIR `Coding.display` is validated against — and were not additionally reconciled against the official LOINC release file.

### Sources

* G-BA Kinder-Richtlinie, version of 15 May 2025, in force 1 January 2026 — § 17 (target conditions), 23 ff. (cystic fibrosis)
* LOINC 2.82 via tx.fhir.org
* LOINC-SNOMED edition, Snowstorm branch `MAIN/SNOMEDCT-LOINC`, version 2026-03-21
* ORPHA 2025 and ICD-10-GM 2026 via the MII Ontoserver

