# Datasets and Descriptions - MII IG Kerndatensatz-Modul Seltene Erkrankungen v2027.0.0-ballot.rc1

* [**Table of Contents**](toc.md)
* **Datasets and Descriptions**

## Datasets and Descriptions

Note that the logical model aims purely at representing the data elements and their descriptions. The data types and cardinalities used are not to be regarded as binding; these are conclusively defined by the FHIR profiles. For every element within the logical model there is a 1:1 mapping to an element of a concrete FHIR resource.

The associated logical model can be found in the artifact overview (see [Artifacts](artifacts.md)); its data elements are listed in full below.

> **Written during migration - review before release.** The logical model was reactivated on 2026-09-02 (it had been parked as `disabled/mii-lm-seltene.fsh.disabled` and builds without error). It is therefore part of the build again, and the 22 unresolvable mapping links every profile carried are resolved.

The table below is generated from the published logical model (`mii-lm-seltene`) and lists every data element with its cardinality, type and description. Indentation reflects nesting.

| | | | |
| :--- | :--- | :--- | :--- |
| `anamneseUndDiagnostik` | 0..* | BackboneElement | Diagnose |
|     `untersuchungsdatum` | 0..1 | date | Datum der durchgeführten Untersuchung eines SE-Patienten. |
|     `untersuchungsanlass` | 0..1 | code | Grund für den Besuch des SE-Patienten. |
|     `phaenotypisierung` | 0..* | BackboneElement | Phänotypisierung |
|         `hpoTerm` | 0..* | code | Phänotypisierung des SE-Patienten mittels HPO-Term (Human Phenotype Ontology) oder anderer Terminologien (SNOMED CT, ICD-10, LOINC). |
|         `hpoExcluded` | 0..1 | boolean | Gibt an, ob das HPO-Merkmal explizit ausgeschlossen wurde (negated finding). Abgeleitet aus valueCodeableConcept: LOINC LA9634-2 'Absent' = true, LA9633-4 'Present' = false. Folgt HL7 Phenomics IG Muster. |
|         `hpoStatus` | 0..1 | code | Status oder Schweregrad des Phänotyps (Present/Absent/Severity). |
|         `hpoVersion` | 0..1 | code | Kennzeichnung der genutzten Version des ausgewählten HPO-Terms. |
|         `zeitraumSymptom` | 0..* | BackboneElement | Zeitraum des Symptom |
|             `zeitraumSymptom` | 0..* | dateTime | Startdatum und bei Bedarf Periode der ersten Symptome/Anzeichen. |
|             `lebensphase` | 0..* | code | Lebensphase, in der das Symptom aufgetreten ist. |
|             `alterSymptom` | 0..1 | integer | Alter beim Auftreten der ersten Symptome/Anzeichen. |
|         `verlaufSymptom` | 0..1 | code | Änderung des Verlaufs des Symptoms seit der vorherigen Untersuchung. |
|     `klinischeDiagnose` | 0..* | BackboneElement | Zeitraum der klinischen SE-Diagnose |
|         `zeitpunktKlinischeDia` | 0..1 | code | Auswahl der Altersangabe (Lebensphase) des Zeitpunktes der klinsichen SE-Diagnose. |
|         `feststellungsdatumKlinischeDia` | 0..1 | date | Datum, an dem die klinische SE-Diagnose festgestellt wurde. |
|         `alterKlinischeDia` | 0..1 | integer | Alter, in dem die klinische SE-Diagnose gestellt wurde. |
|     `genetischeDiagnose` | 0..* | BackboneElement | Zeitraum der genetischen SE-Diagnose |
|         `omimCode` | 0..* | code | Kennung der Erkrankung in Online Mendelian Inheritance in Man. Ergaenzt die Kodierung aus dem Modul Diagnose um die genspezifische Zuordnung; fuer monogene Erkrankungen praeziser als ICD-10-GM. |
|         `zeitpunktGenDia` | 0..1 | code | Auswahl der Altersangabe (Lebensphase) des Zeitpunktes der genetischen SE-Diagnose. |
|         `feststellungsdatumGenDia` | 0..1 | date | Datum, an dem die genetische SE-Diagnose festgestellt wurde. |
|         `alterGenDia` | 0..1 | integer | Alter, in dem die genetische SE-Diagnose gestellt wurde. |
|     `genDiaFehlendePenetranz` | 0..* | code | Gibt an, ob bei einer genetischen Diagnose die Penetranz (Wahrscheinlichkeit Genotyp bildet Phänotyp aus) fehlt |
|     `methodeDiagnosestellung` | 0..* | code | Gibt an, welche Methode zur Diagnosestellung verwendet wurde. |
| `koerperlicheUntersuchung` | 0..* | BackboneElement | Körperliche Untersuchung |
|     `koerpergewicht` | 0..* | BackboneElement | Körpergewicht |
|         `koerpergewicht` | 0..1 | decimal | Körpergewicht des SE-Patienten in kg (aus MII ICU Modul). |
|         `datumKoerpergewicht` | 0..1 | dateTime | Datum der Körpergewichtsmessung. |
|     `koerpergroesse` | 0..* | BackboneElement | Körpergröße |
|         `koerpergroesse` | 0..1 | decimal | Körpergröße des SE-Patienten in cm (aus MII ICU Modul). |
|         `datumKoerpergroesse` | 0..1 | dateTime | Datum der Körpergrößenmessung. |
|     `bmi` | 0..* | BackboneElement | BMI |
|         `bmi` | 0..1 | decimal | BMI des SE-Patienten. |
|         `datumBMI` | 0..1 | dateTime | Datum, an dem der BMI (Body Mass Index) berechnet wurde. |
|     `kopfumfang` | 0..* | BackboneElement | Kopfumfang |
|         `kopfumfang` | 0..1 | decimal | Kopfumfang des SE-Patienten in cm. |
|         `datumKopfumfang` | 0..1 | dateTime | Datum der Kopfumfangsmessung. |
|     `bauchumfang` | 0..* | BackboneElement | Bauchumfang |
|         `bauchumfang` | 0..1 | decimal | Bauchumfang des SE-Patienten in cm. |
|         `datumBauchumfang` | 0..1 | dateTime | Datum der Bauchumfangsmessung. |
|     `taillenumfang` | 0..* | BackboneElement | Taillenumfang |
|         `taillenumfang` | 0..1 | decimal | Taillenumfang des SE-Patienten in cm. Abzugrenzen vom Bauchumfang, der auf Nabelhöhe gemessen wird. |
|         `datumTaillenumfang` | 0..1 | dateTime | Datum der Taillenumfangsmessung. |
|     `hueftumfang` | 0..* | BackboneElement | Hüftumfang |
|         `hueftumfang` | 0..1 | decimal | Hüftumfang des SE-Patienten in cm. |
|         `datumHueftumfang` | 0..1 | dateTime | Datum der Hüftumfangsmessung. |
|     `blutgruppe` | 0..1 | code | Blutgruppe des SE-Patienten (AB0 und Rhesusfaktor). |
| `persoenlicheInfosIndexpatient` | 0..* | BackboneElement | Persönliche Informationen des Indexpatienten |
|     `tod` | 0..1 | BackboneElement | Tod |
|         `sterbedatum` | 0..1 | date | Sterbedatum des Indexpatienten. |
|         `anSEVerstorben` | 0..1 | code | Angabe, ob der Indexpatient an der SE verstorben ist. |
|         `andereTodesursache` | 0..* | code | Kodierung der Todesursache soweit bekannt (ICD-10-GM, ORPHAcodes). |
| `familienanamnese` | 0..* | BackboneElement | Familienanamnese |
|     `verwandtschaftsverhaeltnis` | 0..1 | code | Biologisches Verwandtschaftsverhältnis des Familienmitglieds zum Indexpatienten. |
|     `geschlecht` | 0..1 | code | Geschlecht des Familienmitglieds. |
|     `gleicheSE` | 0..* | code | Gibt an, ob das Familienmitglied an der gleichen SE leidet wie der Indexpatient. |
|     `andereSE` | 0..* | code | Gibt an, ob das Familienmitglied an einer anderen SE leidet als der Indexpatient. |
|     `penetranz` | 0..1 | code | Gibt an, ob bei fehlender klinscher Penetranz (Wahrscheinlichkeit Genotyp bildet Phänotyp aus) die genetische Diagnose vorliegt. |
|     `familienmitgliedVerstorben` | 0..1 | code | Gibt an, ob das Familienmitglied verstorben ist. |
|     `todDurchSE` | 0..1 | code | Gibt an, ob die seltene Erkrankung zum Tod des Familienmitglieds beigetragen hat. Abzugrenzen von familienmitgliedVerstorben, das nur den Tod als solchen festhält. |
|     `dokumentationsdatum` | 0..1 | date | Datum, an dem die Familienanamnese erhoben beziehungsweise dokumentiert wurde. |
|     `konsanguinitaetEltern` | 0..1 | code | Gibt an, ob die biologischen Eltern des Indexpatienten blutsverwandt sind (RD-CDM v2.0.0 6.4.4). |
| `perinatal` | 0..* | BackboneElement | Prä- und perinatale Angaben |
|     `gestationsalter` | 0..1 | decimal | Vollendete Schwangerschaftswochen bei Geburt des Indexpatienten. |
|     `geburtsgewicht` | 0..1 | decimal | Geburtsgewicht des Indexpatienten in Gramm. |
|     `geburtslaenge` | 0..1 | decimal | Körperlänge des Indexpatienten bei Geburt in Zentimetern. |
| `funktionsfaehigkeit` | 0..* | BackboneElement | Funktionsfähigkeit und Behinderung (ICF) |
|     `icfCode` | 0..1 | code | Kode der Internationalen Klassifikation der Funktionsfähigkeit, Behinderung und Gesundheit. |
|     `beurteilungsmerkmal` | 0..* | code | WHO-Qualifier zum ICF-Kode. Ihre Zahl ist je Kapitel verschieden: Körperstrukturen tragen drei, Aktivitäten und Partizipation zwei. |
|     `erhebungsdatum` | 0..1 | date | Datum der ICF-Einstufung. |
| `registerteilnahme` | 0..* | BackboneElement | Teilnahme an Registern |
|     `registerName` | 0..1 | code | Register, an dem der Indexpatient teilnimmt, insbesondere ein Register eines Europäischen Referenznetzwerks (ERN). |
|     `teilnahmestatus` | 0..1 | code | Status der Teilnahme am Register. |
|     `teilnahmezeitraum` | 0..1 | Period | Zeitraum der Teilnahme am Register. |
| `therapieForschung` | 0..* | BackboneElement | Therapie und Forschung |
|     `offLabel` | 0..* | BackboneElement | Off-Label-Gabe |
|         `offLabelGabe` | 0..1 | code | Gibt an, ob eine Off-Label-Gabe vorliegt. |
|         `offLabelMedikament` | 0..* | code | Gibt an, welches Medikament Off-Label gegeben wurde. |
|     `studie` | 0..* | BackboneElement | Studie |
|         `studienID` | 0..1 | Identifier | Eindeutige Identifikation der Studie, an der der SE-Patient teilgenommen hat. |
|         `studienStatus` | 0..1 | code | Aktueller Status der Studie, an der der SE-Patient teilgenommen hat (Abgeschlossen, Fortlaufend). |
|         `studienzeitraum` | 0..1 | Extension | Zeitraum, in dem der SE-Patient an der Studie teilgenommen hat. |
|     `therapie` | 0..* | BackboneElement | Therapie |
|         `therapieempfehlung` | 0..* | code | Gibt an, welche Therapieempfehlung vorliegt. |
|         `durchgefuehrteTherapie` | 0..* | code | Tatsächlich durchgeführte Therapie des SE-Patienten (mit oder ohne Studie mit heilender Intention). |
|         `startdatumTherapie` | 0..1 | date | Datum, an dem die Therapie begonnen hat. |
|         `enddatumTherapie` | 0..1 | date | Datum, an dem die Therapie beendet wurde. |
|         `grundEndeTherapie` | 0..* | code | Gibt an, warum die Therapie beendet wurde (z.B. Nebenwirkungen, keine Wirkung). |

