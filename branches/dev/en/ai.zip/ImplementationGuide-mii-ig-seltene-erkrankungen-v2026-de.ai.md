# Resource MII IG Kerndatensatz-Modul Seltene Erkrankungen



## Resource Content

```json
{
  "resourceType" : "ImplementationGuide",
  "id" : "mii-ig-seltene-erkrankungen-v2026-de",
  "language" : "en",
  "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/ImplementationGuide/mii-ig-seltene-erkrankungen-v2026-de",
  "version" : "2026.0.1",
  "name" : "MIIIGModulSelteneErkrankungen",
  "title" : "MII IG Kerndatensatz-Modul Seltene Erkrankungen",
  "status" : "active",
  "date" : "2026-07-23T11:20:28+00:00",
  "publisher" : "Medizininformatik Initiative",
  "contact" : [{
    "name" : "Medizininformatik Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de/"
    }]
  }],
  "packageId" : "mii-ig-seltene-erkrankungen-v2026-de",
  "license" : "CC0-1.0",
  "fhirVersion" : ["4.0.1"],
  "dependsOn" : [{
    "id" : "hl7tx",
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
      "valueMarkdown" : "Automatically added as a dependency - all IGs depend on HL7 Terminology"
    }],
    "uri" : "http://terminology.hl7.org/ImplementationGuide/hl7.terminology",
    "packageId" : "hl7.terminology.r4",
    "version" : "7.2.0"
  },
  {
    "id" : "hl7ext",
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
      "valueMarkdown" : "Automatically added as a dependency - all IGs depend on the HL7 Extension Pack"
    }],
    "uri" : "http://hl7.org/fhir/extensions/ImplementationGuide/hl7.fhir.uv.extensions",
    "packageId" : "hl7.fhir.uv.extensions.r4",
    "version" : "5.3.0"
  },
  {
    "id" : "de_basisprofil_r4",
    "uri" : "http://fhir.org/packages/de.basisprofil.r4/ImplementationGuide/de.basisprofil.r4",
    "packageId" : "de.basisprofil.r4",
    "version" : "1.5.x"
  },
  {
    "id" : "de_medizininformatikinitiative_kerndatensatz_meta",
    "uri" : "https://www.medizininformatik-initiative.de/fhir/modul-meta/ImplementationGuide/mii-ig-meta",
    "packageId" : "de.medizininformatikinitiative.kerndatensatz.meta",
    "version" : "2026.0.x"
  },
  {
    "id" : "de_medizininformatikinitiative_kerndatensatz_molgen",
    "uri" : "http://fhir.org/packages/de.medizininformatikinitiative.kerndatensatz.molgen/ImplementationGuide/de.medizininformatikinitiative.kerndatensatz.molgen",
    "packageId" : "de.medizininformatikinitiative.kerndatensatz.molgen",
    "version" : "2026.0.x"
  },
  {
    "id" : "de_medizininformatikinitiative_kerndatensatz_icu",
    "uri" : "http://fhir.org/packages/de.medizininformatikinitiative.kerndatensatz.icu/ImplementationGuide/de.medizininformatikinitiative.kerndatensatz.icu",
    "packageId" : "de.medizininformatikinitiative.kerndatensatz.icu",
    "version" : "2026.0.x"
  },
  {
    "id" : "de_medizininformatikinitiative_kerndatensatz_studie",
    "uri" : "http://fhir.org/packages/de.medizininformatikinitiative.kerndatensatz.studie/ImplementationGuide/de.medizininformatikinitiative.kerndatensatz.studie",
    "packageId" : "de.medizininformatikinitiative.kerndatensatz.studie",
    "version" : "2026.0.2"
  },
  {
    "id" : "de_medizininformatikinitiative_kerndatensatz_base",
    "uri" : "https://www.medizininformatik-initiative.de/fhir/modul-base/ImplementationGuide/mii-ig-base",
    "packageId" : "de.medizininformatikinitiative.kerndatensatz.base",
    "version" : "2026.0.x"
  },
  {
    "id" : "de_medizininformatikinitiative_kerndatensatz_medikation",
    "uri" : "https://www.medizininformatik-initiative.de/fhir/core/modul-medikation/ImplementationGuide/mii-ig-medikation",
    "packageId" : "de.medizininformatikinitiative.kerndatensatz.medikation",
    "version" : "2026.0.x"
  }],
  "definition" : {
    "extension" : [{
      "extension" : [{
        "url" : "code",
        "valueString" : "copyrightyear"
      },
      {
        "url" : "value",
        "valueString" : "2022+"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "releaselabel"
      },
      {
        "url" : "value",
        "valueString" : "ci-build"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "excludettl"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "autoload-resources"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "template/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "input/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-qa"
      },
      {
        "url" : "value",
        "valueString" : "temp/qa"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-temp"
      },
      {
        "url" : "value",
        "valueString" : "temp/pages"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-output"
      },
      {
        "url" : "value",
        "valueString" : "output"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-suppressed-warnings"
      },
      {
        "url" : "value",
        "valueString" : "input/ignoreWarnings.txt"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-history"
      },
      {
        "url" : "value",
        "valueString" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/history.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "template-html"
      },
      {
        "url" : "value",
        "valueString" : "template-page.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "template-md"
      },
      {
        "url" : "value",
        "valueString" : "template-page-md.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-contact"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-context"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-copyright"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-jurisdiction"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-license"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-publisher"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-version"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-wg"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "active-tables"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "fmm-definition"
      },
      {
        "url" : "value",
        "valueString" : "http://hl7.org/fhir/versions.html#maturity"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "propagate-status"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "excludelogbinaryformat"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "tabbed-snapshots"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "i18n-default-lang"
      },
      {
        "url" : "value",
        "valueString" : "en"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "wantGen-ttl"
      },
      {
        "url" : "value",
        "valueString" : "false"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "wantGen-ttl-html"
      },
      {
        "url" : "value",
        "valueString" : "false"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-internal-dependency",
      "valueCode" : "hl7.fhir.uv.tools.r4#1.1.2"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "copyrightyear"
      },
      {
        "url" : "value",
        "valueString" : "2022+"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "releaselabel"
      },
      {
        "url" : "value",
        "valueString" : "ci-build"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "excludettl"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "autoload-resources"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "template/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "input/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-qa"
      },
      {
        "url" : "value",
        "valueString" : "temp/qa"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-temp"
      },
      {
        "url" : "value",
        "valueString" : "temp/pages"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-output"
      },
      {
        "url" : "value",
        "valueString" : "output"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-suppressed-warnings"
      },
      {
        "url" : "value",
        "valueString" : "input/ignoreWarnings.txt"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-history"
      },
      {
        "url" : "value",
        "valueString" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/history.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "template-html"
      },
      {
        "url" : "value",
        "valueString" : "template-page.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "template-md"
      },
      {
        "url" : "value",
        "valueString" : "template-page-md.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-contact"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-context"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-copyright"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-jurisdiction"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-license"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-publisher"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-version"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-wg"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "active-tables"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "fmm-definition"
      },
      {
        "url" : "value",
        "valueString" : "http://hl7.org/fhir/versions.html#maturity"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "propagate-status"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "excludelogbinaryformat"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "tabbed-snapshots"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "i18n-default-lang"
      },
      {
        "url" : "value",
        "valueString" : "en"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "wantGen-ttl"
      },
      {
        "url" : "value",
        "valueString" : "false"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "wantGen-ttl-html"
      },
      {
        "url" : "value",
        "valueString" : "false"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    }],
    "resource" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-observation-alt-001.html"
      }],
      "reference" : {
        "reference" : "Observation/observation-alt-001"
      },
      "name" : "ALT Labor - Post-therapeutisch",
      "description" : "ALT Wert nach Gentherapie",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-encounter-ambulant-001.html"
      }],
      "reference" : {
        "reference" : "Encounter/encounter-ambulant-001"
      },
      "name" : "Ambulante Erstvorstellung",
      "description" : "Erstvorstellung im SMA-Zentrum",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-encounter-nachsorge-001.html"
      }],
      "reference" : {
        "reference" : "Encounter/encounter-nachsorge-001"
      },
      "name" : "Ambulante Nachsorge",
      "description" : "Erster Nachsorgetermin nach Gentherapie",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-anteverted-nares.html"
      }],
      "reference" : {
        "reference" : "Observation/anteverted-nares"
      },
      "name" : "Antevertierte Nares - HPO-kodiert",
      "description" : "Nach oben gerichtete Nasenlöcher",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-hpo-assessment"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-symptom-aortic-regurg.html"
      }],
      "reference" : {
        "reference" : "Observation/symptom-aortic-regurg"
      },
      "name" : "Aortenklappeninsuffizienz",
      "description" : "Moderate Aortenklappeninsuffizienz Grad II",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-aortic-root-normal.html"
      }],
      "reference" : {
        "reference" : "Observation/aortic-root-normal"
      },
      "name" : "Aortenwurzel - Normalbefund",
      "description" : "Normale Aortenwurzel, schließt Marfan aus",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-symptom-aortic-root.html"
      }],
      "reference" : {
        "reference" : "Observation/symptom-aortic-root"
      },
      "name" : "Aortenwurzeldilatation",
      "description" : "Pathologisch erweiterte Aortenwurzel",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-aortic-root-dilatation.html"
      }],
      "reference" : {
        "reference" : "Observation/aortic-root-dilatation"
      },
      "name" : "Aortenwurzeldilatation - HPO-kodiert",
      "description" : "Echokardiographisch nachgewiesene Aortenwurzeldilatation",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-hpo-assessment"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-arachnodactyly.html"
      }],
      "reference" : {
        "reference" : "Observation/arachnodactyly"
      },
      "name" : "Arachnodaktylie - HPO-kodiert",
      "description" : "Spinnenfingrigkeit bei Marfan-Syndrom",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-hpo-assessment"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-observation-ast-001.html"
      }],
      "reference" : {
        "reference" : "Observation/observation-ast-001"
      },
      "name" : "AST Labor - Post-therapeutisch",
      "description" : "AST Wert nach Gentherapie",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-encounter-ophthalmology.html"
      }],
      "reference" : {
        "reference" : "Encounter/encounter-ophthalmology"
      },
      "name" : "Augenärztliche Konsultation",
      "description" : "Erstvorstellung beim Augenarzt wegen Katarakt",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-observation-leg-asymmetry.html"
      }],
      "reference" : {
        "reference" : "Observation/observation-leg-asymmetry"
      },
      "name" : "Beinlängendifferenz",
      "description" : "Beinlängendifferenz mit rechts verkürztem Bein",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ServiceRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ServiceRequest-mii-exa-seltene-therapieempfehlung-aortenwurzelersatz-marfan.html"
      }],
      "reference" : {
        "reference" : "ServiceRequest/mii-exa-seltene-therapieempfehlung-aortenwurzelersatz-marfan"
      },
      "name" : "Beispiel Aortenwurzelersatz bei Marfan-Syndrom",
      "description" : "Beispiel einer nicht-medikamentösen Therapieempfehlung für Aortenwurzelersatz bei Marfan-Syndrom",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-therapieempfehlung-nicht-medikamentoes"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ServiceRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ServiceRequest-example-nutrition-therapy-recommendation.html"
      }],
      "reference" : {
        "reference" : "ServiceRequest/example-nutrition-therapy-recommendation"
      },
      "name" : "Beispiel Ernährungstherapie-Empfehlung",
      "description" : "Beispiel einer Ernährungstherapie-Empfehlung bei Phenylketonurie",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-therapieempfehlung-nicht-medikamentoes"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ServiceRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ServiceRequest-example-early-detection-recommendation.html"
      }],
      "reference" : {
        "reference" : "ServiceRequest/example-early-detection-recommendation"
      },
      "name" : "Beispiel Früherkennungsprogramm-Empfehlung",
      "description" : "Beispiel einer Empfehlung für regelmäßige Früherkennungsuntersuchungen",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-therapieempfehlung-nicht-medikamentoes"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ServiceRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ServiceRequest-mii-exa-seltene-therapieempfehlung-genetische-beratung.html"
      }],
      "reference" : {
        "reference" : "ServiceRequest/mii-exa-seltene-therapieempfehlung-genetische-beratung"
      },
      "name" : "Beispiel Genetische Beratung",
      "description" : "Beispiel einer nicht-medikamentösen Therapieempfehlung für genetische Beratung",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-therapieempfehlung-nicht-medikamentoes"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationRequest-mii-exa-seltene-therapieempfehlung-gentherapie-sma.html"
      }],
      "reference" : {
        "reference" : "MedicationRequest/mii-exa-seltene-therapieempfehlung-gentherapie-sma"
      },
      "name" : "Beispiel Gentherapie bei SMA",
      "description" : "Beispiel einer medikamentösen Therapieempfehlung für Gentherapie bei Spinaler Muskelatrophie",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-therapieempfehlung"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationRequest-mii-exa-seltene-therapieempfehlung-losartan-marfan.html"
      }],
      "reference" : {
        "reference" : "MedicationRequest/mii-exa-seltene-therapieempfehlung-losartan-marfan"
      },
      "name" : "Beispiel Losartan bei Marfan-Syndrom",
      "description" : "Beispiel einer medikamentösen Therapieempfehlung für Losartan zur Progressionshemmung bei Marfan-Syndrom",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-therapieempfehlung"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-seltene-narse-gentherapie-sma.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-seltene-narse-gentherapie-sma"
      },
      "name" : "Beispiel NARSE Gentherapie bei SMA",
      "description" : "Beispiel einer durchgeführten Gentherapie bei Spinaler Muskelatrophie",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-therapie-durchgefuehrt"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-mii-exa-seltene-narse-stoffwechseltherapie-pompe.html"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-seltene-narse-stoffwechseltherapie-pompe"
      },
      "name" : "Beispiel NARSE Stoffwechseltherapie bei Morbus Pompe",
      "description" : "Beispiel einer durchgeführten Enzymersatztherapie bei Morbus Pompe",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-therapie-durchgefuehrt"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ServiceRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ServiceRequest-mii-exa-seltene-therapieempfehlung-physiotherapie-sma.html"
      }],
      "reference" : {
        "reference" : "ServiceRequest/mii-exa-seltene-therapieempfehlung-physiotherapie-sma"
      },
      "name" : "Beispiel Physiotherapie bei SMA",
      "description" : "Beispiel einer nicht-medikamentösen Therapieempfehlung für Physiotherapie bei Spinaler Muskelatrophie",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-therapieempfehlung-nicht-medikamentoes"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-example.html"
      }],
      "reference" : {
        "reference" : "Patient/example"
      },
      "name" : "Beispielpatient",
      "description" : "Generischer Beispielpatient für Testzwecke",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-seltene-bodymassindex.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-seltene-bodymassindex"
      },
      "name" : "Body Mass Index (BMI) Example",
      "description" : "Example of a Body Mass Index (BMI) observation for a patient.",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-bodymassindex"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-mii-pr-seltene-bodymassindex.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-seltene-bodymassindex"
      },
      "name" : "Body Mass Index (BMI) of the patient",
      "description" : "Describes the Body Mass Index (BMI) of the patient.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-molgen-variant-brca1-pathogenic.html"
      }],
      "reference" : {
        "reference" : "Observation/molgen-variant-brca1-pathogenic"
      },
      "name" : "BRCA1 Pathogene Variante - MolGen",
      "description" : "Pathogene BRCA1-Variante",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DiagnosticReport"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DiagnosticReport-molgen-brca-panel.html"
      }],
      "reference" : {
        "reference" : "DiagnosticReport/molgen-brca-panel"
      },
      "name" : "BRCA1/2 Panel - Diagnostische Implikation",
      "description" : "Hereditäres Karzinom-Panel",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DiagnosticReport"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DiagnosticReport-molgen-cf-diagnostic.html"
      }],
      "reference" : {
        "reference" : "DiagnosticReport/molgen-cf-diagnostic"
      },
      "name" : "CF Diagnostische Implikation - MolGen",
      "description" : "Mukoviszidose genetischer Befund",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-molgen-variant-cftr-f508del-homozygous.html"
      }],
      "reference" : {
        "reference" : "Observation/molgen-variant-cftr-f508del-homozygous"
      },
      "name" : "CFTR F508del Homozygot - MolGen Variante",
      "description" : "Homozygote F508del Mutation bei Mukoviszidose",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-chronic-diarrhea.html"
      }],
      "reference" : {
        "reference" : "Observation/chronic-diarrhea"
      },
      "name" : "Chronische Diarrhoe - HPO-kodiert",
      "description" : "Chronische Durchfälle bei CF",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-hpo-assessment"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DiagnosticReport"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DiagnosticReport-molgen-diagnostic-dmd.html"
      }],
      "reference" : {
        "reference" : "DiagnosticReport/molgen-diagnostic-dmd"
      },
      "name" : "DMD Diagnostische Implikation",
      "description" : "Diagnostischer Bericht Duchenne-Muskeldystrophie",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-molgen-variant-dmd-deletion-exon45-47.html"
      }],
      "reference" : {
        "reference" : "Observation/molgen-variant-dmd-deletion-exon45-47"
      },
      "name" : "DMD Exon 45-47 Deletion - MolGen Variante",
      "description" : "Out-of-frame Deletion im DMD-Gen",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-example-dmd-excluded-bmd-confirmed.html"
      }],
      "reference" : {
        "reference" : "Condition/example-dmd-excluded-bmd-confirmed"
      },
      "name" : "Duchenne ausgeschlossen - Becker bestätigt",
      "description" : "Duchenne-Muskeldystrophie ausgeschlossen, stattdessen Becker-Muskeldystrophie",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-genetic-diagnosis"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-example-dmd-genetic-diagnosis.html"
      }],
      "reference" : {
        "reference" : "Condition/example-dmd-genetic-diagnosis"
      },
      "name" : "Duchenne-Muskeldystrophie - Genetisch bestätigt",
      "description" : "Beispiel einer genetisch bestätigten Duchenne-Muskeldystrophie",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-genetic-diagnosis"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-observation-echo-av.html"
      }],
      "reference" : {
        "reference" : "Observation/observation-echo-av"
      },
      "name" : "Echokardiographie - Aortenklappeninsuffizienz",
      "description" : "Beurteilung der Aortenklappeninsuffizienz",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-observation-echo-aortic.html"
      }],
      "reference" : {
        "reference" : "Observation/observation-echo-aortic"
      },
      "name" : "Echokardiographie - Aortenwurzeldurchmesser",
      "description" : "Aortenwurzeldurchmesser in der Echokardiographie",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-observation-echo-mv.html"
      }],
      "reference" : {
        "reference" : "Observation/observation-echo-mv"
      },
      "name" : "Echokardiographie - Mitralklappeninsuffizienz",
      "description" : "Beurteilung der Mitralklappeninsuffizienz",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-example-eds-excluded-clinical.html"
      }],
      "reference" : {
        "reference" : "Condition/example-eds-excluded-clinical"
      },
      "name" : "Ehlers-Danlos-Syndrom - Ausgeschlossen",
      "description" : "Differentialdiagnose EDS ausgeschlossen",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-clinical-diagnosis"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "FamilyMemberHistory"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "FamilyMemberHistory-family-history-001.html"
      }],
      "reference" : {
        "reference" : "FamilyMemberHistory/family-history-001"
      },
      "name" : "Familienanamnese - Urgroßmutter mit Muskelerkrankung",
      "description" : "Urgroßmutter mit unbekannter Muskelerkrankung",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-familienanamnese"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-variant-fbn1-001.html"
      }],
      "reference" : {
        "reference" : "Observation/variant-fbn1-001"
      },
      "name" : "FBN1 Gen - Pathogene Mutation",
      "description" : "Pathogene FBN1-Mutation bei Marfan-Syndrom",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-failure-to-thrive.html"
      }],
      "reference" : {
        "reference" : "Observation/failure-to-thrive"
      },
      "name" : "Gedeihstörung - HPO-kodiert",
      "description" : "Mangelhafte Gewichtszunahme",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-hpo-assessment"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-procedure-gentherapy-001.html"
      }],
      "reference" : {
        "reference" : "Procedure/procedure-gentherapy-001"
      },
      "name" : "Gentherapie Verabreichung",
      "description" : "Verabreichung des Gentherapeutikums für SMA",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-procedure-aortic-planned.html"
      }],
      "reference" : {
        "reference" : "Procedure/procedure-aortic-planned"
      },
      "name" : "Geplante Aortenwurzelersatz-Operation",
      "description" : "Geplante David-Operation (Valve-sparing root replacement)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-encounter-surgery-planned.html"
      }],
      "reference" : {
        "reference" : "Encounter/encounter-surgery-planned"
      },
      "name" : "Geplante Herzchirurgie",
      "description" : "Geplanter stationärer Aufenthalt für Aortenwurzelersatz",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-example-brca1-genetic-diagnosis.html"
      }],
      "reference" : {
        "reference" : "Condition/example-brca1-genetic-diagnosis"
      },
      "name" : "Hereditäres Mamma- und Ovarialkarzinom-Syndrom",
      "description" : "Genetisch bestätigtes BRCA1-assoziiertes Karzinom-Syndrom",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-genetic-diagnosis"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-tall-stature.html"
      }],
      "reference" : {
        "reference" : "Observation/tall-stature"
      },
      "name" : "Hochwuchs - HPO-kodiert",
      "description" : "Pathologisch erhöhte Körpergröße",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-hpo-assessment"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-seltene-hpo-assessment-excluded.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-seltene-hpo-assessment-excluded"
      },
      "name" : "HPO Assessment - Excluded Phenotype",
      "description" : "Example of an explicitly excluded phenotype (arachnodactyly ruled out during Marfan syndrome workup).",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-hpo-assessment"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-seltene-hpo-assessment-severity.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-seltene-hpo-assessment-severity"
      },
      "name" : "HPO Assessment - Present with Severity",
      "description" : "Example of a phenotype with both status (present) and severity grading. Demonstrates HL7 Phenomics IG component pattern.",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-hpo-assessment"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-seltene-hpo-assessment-change-status.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-seltene-hpo-assessment-change-status"
      },
      "name" : "HPO Assessment mit Änderungsstatus",
      "description" : "Beispiel einer HPO-Beobachtung mit dokumentiertem Änderungsstatus",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-hpo-assessment"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-mii-vs-seltene-hpo-presence-status.html"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-seltene-hpo-presence-status"
      },
      "name" : "HPO Phenotype Presence Status",
      "description" : "LOINC codes for indicating presence or absence of phenotypic features. Follows HL7 Phenomics IG pattern.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-mii-vs-seltene-hpo-phenotypic-observation-codes.html"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-seltene-hpo-phenotypic-observation-codes"
      },
      "name" : "HPO Phenotypic Observation Codes",
      "description" : "Human Phenotype Ontology codes for phenotypic observations",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-mii-vs-seltene-hpo-severity.html"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-seltene-hpo-severity"
      },
      "name" : "HPO Severity",
      "description" : "HPO codes for describing severity of phenotypic abnormalities. Follows HL7 Phenomics IG component pattern.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-seltene-hpo-assessment.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-seltene-hpo-assessment"
      },
      "name" : "HPO Symptom Observation Example",
      "description" : "Example of an HPO-based phenotypic observation for intellectual disability.",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-hpo-assessment"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-hypertelorism.html"
      }],
      "reference" : {
        "reference" : "Observation/hypertelorism"
      },
      "name" : "Hypertelorismus - HPO-kodiert",
      "description" : "Vergrößerter Augenabstand",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-hpo-assessment"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-seltene-hueftumfang.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-seltene-hueftumfang"
      },
      "name" : "Hüftumfang Beispiel",
      "description" : "Beispiel einer Hüftumfang-Messung bei einem Patienten mit seltener Erkrankung.",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-hueftumfang"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-encounter-cardiology.html"
      }],
      "reference" : {
        "reference" : "Encounter/encounter-cardiology"
      },
      "name" : "Kardiologische Erstvorstellung",
      "description" : "Ambulante kardiologische Erstvorstellung bei Thoraxschmerzen",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-condition-cataract.html"
      }],
      "reference" : {
        "reference" : "Condition/condition-cataract"
      },
      "name" : "Katarakt bilateral",
      "description" : "Beidseitige Katarakt bei Marfan-Syndrom",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-clinical-diagnosis"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-symptom-cataract.html"
      }],
      "reference" : {
        "reference" : "Observation/symptom-cataract"
      },
      "name" : "Katarakt bilateral",
      "description" : "Beidseitige Katarakt als ophthalmologische Manifestation",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-procedure-cataract-surgery.html"
      }],
      "reference" : {
        "reference" : "Procedure/procedure-cataract-surgery"
      },
      "name" : "Katarakt-Operation",
      "description" : "Phakoemulsifikation mit Intraokularlinsenimplantation",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-encounter-cataract-surgery.html"
      }],
      "reference" : {
        "reference" : "Encounter/encounter-cataract-surgery"
      },
      "name" : "Katarakt-Operation Aufenthalt",
      "description" : "Tagesklinischer Aufenthalt für Katarakt-Operation",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ClinicalImpression"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ClinicalImpression-clinical-impression-erstvorstellung.html"
      }],
      "reference" : {
        "reference" : "ClinicalImpression/clinical-impression-erstvorstellung"
      },
      "name" : "Klinische Beurteilung - Erstvorstellung",
      "description" : "Initiale klinische Beurteilung bei Erstvorstellung im SMA-Zentrum",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-clinical-impression"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ClinicalImpression"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ClinicalImpression-clinical-impression-nachsorge.html"
      }],
      "reference" : {
        "reference" : "ClinicalImpression/clinical-impression-nachsorge"
      },
      "name" : "Klinische Beurteilung - Nachsorge",
      "description" : "Nachsorgeuntersuchung nach Gentherapie",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-clinical-impression"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ClinicalImpression"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ClinicalImpression-clinical-impression-seltene-assessment.html"
      }],
      "reference" : {
        "reference" : "ClinicalImpression/clinical-impression-seltene-assessment"
      },
      "name" : "Konsultation ZSE bei V.a. Marfan-Syndrom",
      "description" : "Konsultation im Zentrum für Seltene Erkrankungen mit kardiologischer Mitbeurteilung bei V.a. Marfan-Syndrom",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-clinical-impression"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-seltene-kopfumfang.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-seltene-kopfumfang"
      },
      "name" : "Kopfumfang Beispiel",
      "description" : "Beispiel einer Kopfumfang-Messung bei einem Patienten mit seltener Erkrankung.",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-kopfumfang"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-observation-height-001.html"
      }],
      "reference" : {
        "reference" : "Observation/observation-height-001"
      },
      "name" : "Körpergröße - Hochwuchs",
      "description" : "Pathologisch erhöhte Körpergröße bei Marfan-Syndrom",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-lens-dislocation.html"
      }],
      "reference" : {
        "reference" : "Observation/lens-dislocation"
      },
      "name" : "Linsenluxation - HPO-kodiert",
      "description" : "Ectopia lentis bei Marfan-Syndrom",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-hpo-assessment"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "MedicationStatement-medication-losartan.html"
      }],
      "reference" : {
        "reference" : "MedicationStatement/medication-losartan"
      },
      "name" : "Losartan Therapie",
      "description" : "Losartan zur Progressionshemmung der Aortenwurzeldilatation",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-lymphedema.html"
      }],
      "reference" : {
        "reference" : "Observation/lymphedema"
      },
      "name" : "Lymphödem - HPO-kodiert",
      "description" : "Peripheres Lymphödem",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-hpo-assessment"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-patient-marfan-001.html"
      }],
      "reference" : {
        "reference" : "Patient/patient-marfan-001"
      },
      "name" : "Marfan Patient - 19-jähriger Mann",
      "description" : "19-jähriger männlicher Patient mit bestätigtem Marfan-Syndrom",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-condition-marfan-genetic.html"
      }],
      "reference" : {
        "reference" : "Condition/condition-marfan-genetic"
      },
      "name" : "Marfan-Syndrom - Genetische Diagnose",
      "description" : "Genetisch bestätigtes Marfan-Syndrom mit FBN1-Mutation",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-genetic-diagnosis"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-example-marfan-excluded-clinical.html"
      }],
      "reference" : {
        "reference" : "Condition/example-marfan-excluded-clinical"
      },
      "name" : "Marfan-Syndrom - Klinisch ausgeschlossen",
      "description" : "Beispiel einer klinisch ausgeschlossenen Marfan-Diagnose",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-clinical-diagnosis"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-example-marfan-clinical-diagnosis.html"
      }],
      "reference" : {
        "reference" : "Condition/example-marfan-clinical-diagnosis"
      },
      "name" : "Marfan-Syndrom - Klinische Diagnose",
      "description" : "Beispiel einer klinischen Diagnose des Marfan-Syndroms basierend auf phänotypischen Merkmalen",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-clinical-diagnosis"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-condition-marfan-clinical.html"
      }],
      "reference" : {
        "reference" : "Condition/condition-marfan-clinical"
      },
      "name" : "Marfan-Syndrom - Klinische Diagnose",
      "description" : "Klinisch bestätigtes Marfan-Syndrom",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-clinical-diagnosis"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-condition-marfan-suspected.html"
      }],
      "reference" : {
        "reference" : "Condition/condition-marfan-suspected"
      },
      "name" : "Marfan-Syndrom - Verdacht",
      "description" : "Verdacht auf Marfan-Syndrom",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-clinical-diagnosis"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-bundle-marfan-complete.html"
      }],
      "reference" : {
        "reference" : "Bundle/bundle-marfan-complete"
      },
      "name" : "Marfan-Syndrom Fallbeispiel - Vollständiges Transaction Bundle",
      "description" : "Transaction Bundle mit allen Ressourcen für den Marfan-Syndrom Fall",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-example-metabolic-myopathy-excluded.html"
      }],
      "reference" : {
        "reference" : "Condition/example-metabolic-myopathy-excluded"
      },
      "name" : "Metabolische Myopathie - Ausgeschlossen",
      "description" : "Metabolische Myopathie als Differentialdiagnose ausgeschlossen",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-clinical-diagnosis"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CapabilityStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CapabilityStatement-mii-cps-seltene-capabilitystatement.html"
      }],
      "reference" : {
        "reference" : "CapabilityStatement/mii-cps-seltene-capabilitystatement"
      },
      "name" : "MII CPS Seltene Erkrankungen CapabilityStatement",
      "description" : "Das vorliegende CapabilityStatement beschreibt alle verpflichtenden Interaktionen die ein konformes System unterstützen muss, um das Modul Seltene Erkrankungen der Medizininformatik Initiative zu implementieren.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-mii-cs-seltene-empfehlung-status-begruendung.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/mii-cs-seltene-empfehlung-status-begruendung"
      },
      "name" : "MII CS SE Empfehlung Status Begründung",
      "description" : "Begründung bei fehlender Empfehlung",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-mii-cs-seltene-therapieempfehlung-strategie.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/mii-cs-seltene-therapieempfehlung-strategie"
      },
      "name" : "MII CS SE Therapieempfehlung Strategie",
      "description" : "Strategietypen für Therapieempfehlungen bei seltenen Erkrankungen, abgeleitet aus MV GenomSeq",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-mii-cs-seltene-therapieempfehlung-typ.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/mii-cs-seltene-therapieempfehlung-typ"
      },
      "name" : "MII CS SE Therapieempfehlung Typ",
      "description" : "Therapietyp (kausal vs. symptomatisch) für Therapieempfehlungen bei seltenen Erkrankungen, abgeleitet aus MV GenomSeq",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-mii-cs-seltene-hpo-change-status.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/mii-cs-seltene-hpo-change-status"
      },
      "name" : "MII CS Seltene Erkrankungen HPO Change Status",
      "description" : "CodeSystem zur Dokumentation von Änderungen bei HPO-Phänotypen über Zeit",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-mii-cs-seltene-narse-therapietyp.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/mii-cs-seltene-narse-therapietyp"
      },
      "name" : "MII CS Seltene Erkrankungen NARSE Therapietyp",
      "description" : "CodeSystem für NARSE-spezifische Therapietypen bei Seltenen Erkrankungen",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-mii-ex-seltene-age-of-onset.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-ex-seltene-age-of-onset"
      },
      "name" : "MII EX SE Age of Onset",
      "description" : "Extension to capture the age of onset of a rare disease using structured HPO age of onset terms",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-mii-ex-seltene-empfehlung-evidenzgraduierung.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-ex-seltene-empfehlung-evidenzgraduierung"
      },
      "name" : "MII EX SE Empfehlung Evidenzgraduierung",
      "description" : "Evidenzgraduierung der (einzelnen) Empfehlung",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-mii-ex-seltene-empfehlung-prioritaet.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-ex-seltene-empfehlung-prioritaet"
      },
      "name" : "MII EX SE Empfehlung Priorität",
      "description" : "Priorität der (einzelnen) Empfehlung",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-mii-ex-seltene-empfehlung-publikation.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-ex-seltene-empfehlung-publikation"
      },
      "name" : "MII EX SE Empfehlung Publikation",
      "description" : "Verweis auf Publikation der (einzelnen) Empfehlung",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-mii-ex-seltene-genetic-basis.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-ex-seltene-genetic-basis"
      },
      "name" : "MII EX SE Genetic Basis",
      "description" : "Extension to describe the genetic basis of a rare disease",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-mii-ex-seltene-inheritance-pattern.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-ex-seltene-inheritance-pattern"
      },
      "name" : "MII EX SE Inheritance Pattern",
      "description" : "Extension to capture the mode of inheritance of a rare disease",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-mii-ex-seltene-penetrance.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-ex-seltene-penetrance"
      },
      "name" : "MII EX SE Penetrance",
      "description" : "Extension to capture the penetrance of genetic variants associated with a rare disease",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-mii-exa-seltene-symptom-condition.html"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-seltene-symptom-condition"
      },
      "name" : "MII Example SE Symptom Condition",
      "description" : "Example of a symptom condition in the context of rare diseases using HPO codes",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-symptom-condition"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-mii-pr-seltene-blutgruppe.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-seltene-blutgruppe"
      },
      "name" : "MII PR SE Blutgruppe",
      "description" : "Observation-Profil für die Erfassung der Blutgruppe (AB0 und Rhesusfaktor) im Kontext seltener Erkrankungen",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-mii-pr-seltene-clinical-diagnosis.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-seltene-clinical-diagnosis"
      },
      "name" : "MII PR SE Clinical Diagnosis",
      "description" : "Profile for clinical diagnosis of rare diseases with HPO phenotype codes. This profile is used for clinically diagnosed rare diseases based on phenotypic presentation.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-mii-pr-seltene-familienanamnese.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-seltene-familienanamnese"
      },
      "name" : "MII PR SE Familienanamnese",
      "description" : "Dieses Profil beschreibt die Familienanamnese eines Patienten im Kontext von seltenen Erkrankungen, basierend auf dem MolGen Familienanamnese Profil. Für jedes Familienmitglied wird eine separate FamilyMemberHistory-Ressource erstellt. Das Profil unterstützt die Dokumentation von Todesfällen durch seltene Erkrankungen über condition.contributedToDeath. Für den Indexpatienten selbst kann relationship.coding[snomed] = 116154003 | Patient | verwendet werden, um den Tod des Patienten durch eine seltene Erkrankung einheitlich zu dokumentieren.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-mii-pr-seltene-genetic-diagnosis.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-seltene-genetic-diagnosis"
      },
      "name" : "MII PR SE Genetic Diagnosis",
      "description" : "Profile for genetically confirmed diagnosis of rare diseases with OMIM codes and links to MolGen variant/diagnostic implication resources. This profile is used when a rare disease diagnosis has been confirmed through genetic testing.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-mii-pr-seltene-hueftumfang.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-seltene-hueftumfang"
      },
      "name" : "MII PR SE Hüftumfang",
      "description" : "Profil zur Dokumentation des Hüftumfangs (maximale Gesäßprotuberanz) eines Patienten. Relevant für seltene Erkrankungen mit Auswirkungen auf die Körperproportionen, metabolische Erkrankungen oder Skelettdysplasien.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-mii-pr-seltene-kopfumfang.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-seltene-kopfumfang"
      },
      "name" : "MII PR SE Kopfumfang",
      "description" : "Profil zur Dokumentation des Kopfumfangs (okzipital-frontal) eines Patienten. Besonders relevant bei seltenen Erkrankungen mit Auswirkungen auf das Schädelwachstum, z.B. Skelettdysplasien, neurologische Erkrankungen. Erbt vom MII ICU Kopfumfang-Profil.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-mii-pr-seltene-studieneinschluss-anfrage.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-seltene-studieneinschluss-anfrage"
      },
      "name" : "MII PR SE Studieneinschluss Anfrage",
      "description" : "Anfrage zum Studieneinschluss",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-mii-pr-seltene-taillenumfang.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-seltene-taillenumfang"
      },
      "name" : "MII PR SE Taillenumfang",
      "description" : "Profil zur Dokumentation des Taillenumfangs (Bauchumfang auf Nabelhöhe) eines Patienten. Relevant für seltene Erkrankungen mit metabolischen Komponenten oder Skelettdysplasien.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-mii-pr-seltene-therapieempfehlung-kombination.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-seltene-therapieempfehlung-kombination"
      },
      "name" : "MII PR SE Therapieempfehlung Kombinationstherapie",
      "description" : "Therapieempfehlung für eine medikamentöse Kombinationstherapie",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-mii-pr-seltene-therapieempfehlung-nicht-medikamentoes.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-seltene-therapieempfehlung-nicht-medikamentoes"
      },
      "name" : "MII PR SE Therapieempfehlung Nicht-Medikamentös",
      "description" : "Therapieempfehlung für nicht-medikamentöse Interventionen bei seltenen Erkrankungen (z.B. Ernährungstherapie, Gentherapie, Prophylaxe, Früherkennung)",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-mii-pr-seltene-therapieempfehlung.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-seltene-therapieempfehlung"
      },
      "name" : "MII PR SE Therapieempfehlung Systemische Therapie",
      "description" : "Therapieempfehlung für eine medikamentöse Systemische Therapie",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-mii-pr-seltene-therapieplan.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-seltene-therapieplan"
      },
      "name" : "MII PR SE Therapieplan",
      "description" : "Therapieplan",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-mii-pr-seltene-therapie-durchgefuehrt.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-seltene-therapie-durchgefuehrt"
      },
      "name" : "MII PR Seltene Erkrankungen Therapie Durchgeführt",
      "description" : "Minimales Profil zur Dokumentation durchgeführter Therapien bei Seltenen Erkrankungen gemäß NARSE-Klassifikation. Dieses Profil erfasst Therapien unabhängig vom Durchführungsort (ambulant, stationär, außerhalb des Krankenhauses).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-mii-pr-seltene-clinical-impression.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-seltene-clinical-impression"
      },
      "name" : "MII Profile SE Clinical Impression",
      "description" : "Profile for clinical impressions in the context of rare diseases. This profile captures clinical assessments and suspected diagnoses based on phenotypic findings and symptoms.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-mii-pr-seltene-hpo-assessment.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-seltene-hpo-assessment"
      },
      "name" : "MII Profile SE HPO Assessment",
      "description" : "Profile for HPO-based phenotypic observations in the context of rare diseases. This profile uses the Human Phenotype Ontology (HPO) to describe clinical symptoms and phenotypic abnormalities.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-mii-pr-seltene-symptom-condition.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-seltene-symptom-condition"
      },
      "name" : "MII Profile SE Symptom Condition",
      "description" : "Profile for symptom-based conditions in the context of rare diseases. This profile captures symptomatic conditions with temporal characteristics, complementing the HPO Assessment Observation profile.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-mii-vs-seltene-blutgruppe.html"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-seltene-blutgruppe"
      },
      "name" : "MII VS SE Blutgruppe",
      "description" : "ValueSet für Blutgruppen (AB0 und Rhesusfaktor) basierend auf LOINC Answer List für 882-1",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-mii-vs-seltene-clinical-diagnosis-category.html"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-seltene-clinical-diagnosis-category"
      },
      "name" : "MII VS SE Clinical Diagnosis Category",
      "description" : "Value set for categorizing clinical diagnoses of rare diseases",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-mii-vs-seltene-empfehlung-status-begruendung.html"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-seltene-empfehlung-status-begruendung"
      },
      "name" : "MII VS SE Empfehlung Status Begründung",
      "description" : "ValueSet für Begründung bei fehlender Empfehlung",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-mii-vs-seltene-genetic-basis.html"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-seltene-genetic-basis"
      },
      "name" : "MII VS SE Genetic Basis",
      "description" : "Value set for types of genetic basis of rare diseases",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-mii-vs-seltene-hpo-age-of-onset.html"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-seltene-hpo-age-of-onset"
      },
      "name" : "MII VS SE HPO Age of Onset",
      "description" : "Value set containing HPO terms for age of onset of diseases",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-mii-vs-seltene-hpo-inheritance-pattern.html"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-seltene-hpo-inheritance-pattern"
      },
      "name" : "MII VS SE HPO Inheritance Pattern",
      "description" : "Value set containing HPO terms for modes of inheritance",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-mii-vs-seltene-penetrance.html"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-seltene-penetrance"
      },
      "name" : "MII VS SE Penetrance",
      "description" : "Value set for qualitative descriptions of genetic penetrance",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-mii-vs-seltene-therapieempfehlung-strategie.html"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-seltene-therapieempfehlung-strategie"
      },
      "name" : "MII VS SE Therapieempfehlung Strategie",
      "description" : "ValueSet für Strategietypen von Therapieempfehlungen bei seltenen Erkrankungen (Modellvorhaben GenomSeq)",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-mii-vs-seltene-therapieempfehlung-strategie-medikamentoes.html"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-seltene-therapieempfehlung-strategie-medikamentoes"
      },
      "name" : "MII VS SE Therapieempfehlung Strategie - Medikamentös",
      "description" : "ValueSet für medikamentöse Therapiestrategien (für MedicationRequest Profile) - Verwendet für MedicationRequest-basierte Therapieempfehlungen im Kontext Modellvorhaben GenomSeq",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-mii-vs-seltene-therapieempfehlung-strategie-nicht-medikamentoes.html"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-seltene-therapieempfehlung-strategie-nicht-medikamentoes"
      },
      "name" : "MII VS SE Therapieempfehlung Strategie - Nicht-Medikamentös",
      "description" : "ValueSet für nicht-medikamentöse Therapiestrategien (für ServiceRequest Profile) - Verwendet für ServiceRequest-basierte Therapieempfehlungen im Kontext Modellvorhaben GenomSeq",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-mii-vs-seltene-therapieempfehlung-typ.html"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-seltene-therapieempfehlung-typ"
      },
      "name" : "MII VS SE Therapieempfehlung Typ",
      "description" : "ValueSet für Therapietypen (kausal/symptomatisch) bei seltenen Erkrankungen (Modellvorhaben GenomSeq)",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-mii-vs-seltene-hpo-change-status.html"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-seltene-hpo-change-status"
      },
      "name" : "MII VS Seltene Erkrankungen HPO Change Status",
      "description" : "ValueSet für Änderungsstatus von HPO-Phänotypen gemäß Modellvorhaben Genomsequenzierung",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-mii-vs-seltene-narse-therapietyp.html"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-seltene-narse-therapietyp"
      },
      "name" : "MII VS Seltene Erkrankungen NARSE Therapietyp",
      "description" : "ValueSet für NARSE-spezifische Therapietypen bei Seltenen Erkrankungen",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-mii-vs-seltene-symptom-change-status-combined.html"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-seltene-symptom-change-status-combined"
      },
      "name" : "MII VS Seltene Erkrankungen Symptom Change Status (Combined)",
      "description" : "ValueSet zur Dokumentation von Änderungen bei Symptomen/Phänotypen über Zeit. Kombiniert MVGenomSeq-spezifische Codes mit SNOMED CT-Codes für internationale Interoperabilität.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "FamilyMemberHistory"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "FamilyMemberHistory-mii-exa-seltene-familienanamnese.html"
      }],
      "reference" : {
        "reference" : "FamilyMemberHistory/mii-exa-seltene-familienanamnese"
      },
      "name" : "mii-exa-seltene-familienanamnese",
      "description" : "Example Patient Family Anamnesis",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-familienanamnese"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-symptom-mitral-regurg.html"
      }],
      "reference" : {
        "reference" : "Observation/symptom-mitral-regurg"
      },
      "name" : "Mitralklappeninsuffizienz",
      "description" : "Milde Mitralklappeninsuffizienz Grad I",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-example-cf-genetic.html"
      }],
      "reference" : {
        "reference" : "Condition/example-cf-genetic"
      },
      "name" : "Mukoviszidose - Genetisch bestätigt",
      "description" : "Genetisch bestätigte Mukoviszidose",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-genetic-diagnosis"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-example-cf-clinical.html"
      }],
      "reference" : {
        "reference" : "Condition/example-cf-clinical"
      },
      "name" : "Mukoviszidose - Klinischer Verdacht",
      "description" : "Initiale klinische Verdachtsdiagnose Mukoviszidose",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-clinical-diagnosis"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-example-cf-excluded-after-screening.html"
      }],
      "reference" : {
        "reference" : "Condition/example-cf-excluded-after-screening"
      },
      "name" : "Mukoviszidose - Nach positivem Screening ausgeschlossen",
      "description" : "CF nach auffälligem Neugeborenenscreening genetisch ausgeschlossen",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-genetic-diagnosis"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-encounter-screening-001.html"
      }],
      "reference" : {
        "reference" : "Encounter/encounter-screening-001"
      },
      "name" : "Neugeborenenscreening",
      "description" : "Neugeborenenscreening mit SMA-Verdacht",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-example-noonan-clinical-diagnosis.html"
      }],
      "reference" : {
        "reference" : "Condition/example-noonan-clinical-diagnosis"
      },
      "name" : "Noonan-Syndrom - Klinische Diagnose",
      "description" : "Beispiel einer klinischen Diagnose des Noonan-Syndroms",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-clinical-diagnosis"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-mii-ext-seltene-onset-age.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-ext-seltene-onset-age"
      },
      "name" : "Onset Age Extension",
      "description" : "Extension to capture the age at onset of a condition. This backports the onsetAge functionality from FHIR R5 to R4.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-mii-ext-seltene-phenotypic-pattern.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-ext-seltene-phenotypic-pattern"
      },
      "name" : "Phenotypic Pattern Extension",
      "description" : "Extension to link syndrome diagnoses to characteristic phenotypic patterns or symptom clusters",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-condition-pku-diagnosis.html"
      }],
      "reference" : {
        "reference" : "Condition/condition-pku-diagnosis"
      },
      "name" : "Phenylketonurie - Genetische Diagnose",
      "description" : "Genetisch bestätigte Phenylketonurie (PKU)",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-genetic-diagnosis"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-recurrent-respiratory-infections.html"
      }],
      "reference" : {
        "reference" : "Observation/recurrent-respiratory-infections"
      },
      "name" : "Rezidivierende Atemwegsinfekte - HPO-kodiert",
      "description" : "Häufige respiratorische Infektionen bei CF",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-hpo-assessment"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-example-sma-excluded-genetic.html"
      }],
      "reference" : {
        "reference" : "Condition/example-sma-excluded-genetic"
      },
      "name" : "SMA - Genetisch ausgeschlossen",
      "description" : "Spinale Muskelatrophie genetisch ausgeschlossen",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-genetic-diagnosis"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DiagnosticReport"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DiagnosticReport-molgen-diagnostic-implication-sma.html"
      }],
      "reference" : {
        "reference" : "DiagnosticReport/molgen-diagnostic-implication-sma"
      },
      "name" : "SMA Diagnostische Implikation - MolGen",
      "description" : "Diagnostischer Bericht zur SMA-Genetik",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-bundle-sma-complete.html"
      }],
      "reference" : {
        "reference" : "Bundle/bundle-sma-complete"
      },
      "name" : "SMA Fallbeispiel - Vollständiges Transaction Bundle",
      "description" : "Transaction Bundle mit allen Ressourcen für den SMA Fall inkl. Diagnoseverlauf",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DiagnosticReport"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DiagnosticReport-molgen-sma-negative.html"
      }],
      "reference" : {
        "reference" : "DiagnosticReport/molgen-sma-negative"
      },
      "name" : "SMA Genetik - Negativbefund",
      "description" : "Genetischer Test schließt SMA aus",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-condition-sma-genetic.html"
      }],
      "reference" : {
        "reference" : "Condition/condition-sma-genetic"
      },
      "name" : "SMA Genetische Diagnose",
      "description" : "SMA Typ 1, molekulargenetisch bestätigt durch SMN1-Deletion",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-genetic-diagnosis"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-condition-sma-clinical.html"
      }],
      "reference" : {
        "reference" : "Condition/condition-sma-clinical"
      },
      "name" : "SMA Klinische Diagnose",
      "description" : "Klinische Diagnose SMA Typ 1 bei Erstvorstellung",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-clinical-diagnosis"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-observation-sma-screening.html"
      }],
      "reference" : {
        "reference" : "Observation/observation-sma-screening"
      },
      "name" : "SMA Neugeborenenscreening Ergebnis",
      "description" : "Positives SMA-Screening beim Neugeborenenscreening",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-patient-sma-001.html"
      }],
      "reference" : {
        "reference" : "Patient/patient-sma-001"
      },
      "name" : "SMA Patient - Neugeborenes Mädchen",
      "description" : "Neugeborenes Mädchen mit bestätigter SMA Typ 1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-example-sma-genetic-diagnosis.html"
      }],
      "reference" : {
        "reference" : "Condition/example-sma-genetic-diagnosis"
      },
      "name" : "SMA Typ 1 - Genetisch bestätigte Diagnose",
      "description" : "Beispiel einer genetisch bestätigten Diagnose der spinalen Muskelatrophie Typ 1",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-genetic-diagnosis"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-condition-sma-suspected.html"
      }],
      "reference" : {
        "reference" : "Condition/condition-sma-suspected"
      },
      "name" : "SMA Verdacht - Neugeborenenscreening",
      "description" : "Verdacht auf SMA beim Neugeborenenscreening",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-clinical-diagnosis"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-molgen-smn1-normal-copies.html"
      }],
      "reference" : {
        "reference" : "Observation/molgen-smn1-normal-copies"
      },
      "name" : "SMN1 - Normale Kopienanzahl",
      "description" : "2 Kopien SMN1 - schließt SMA aus",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-variant-smn1-001.html"
      }],
      "reference" : {
        "reference" : "Observation/variant-smn1-001"
      },
      "name" : "SMN1 Gen - Homozygote Deletion",
      "description" : "0 Kopien des SMN1-Gens nachgewiesen",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-molgen-variant-smn1-deletion.html"
      }],
      "reference" : {
        "reference" : "Observation/molgen-variant-smn1-deletion"
      },
      "name" : "SMN1 Gen Deletion - MolGen Variante",
      "description" : "Homozygote Deletion des SMN1-Gens bei SMA",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-variant-smn2-001.html"
      }],
      "reference" : {
        "reference" : "Observation/variant-smn2-001"
      },
      "name" : "SMN2 Gen - Kopienanzahl",
      "description" : "2 Kopien des SMN2-Gens nachgewiesen",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-encounter-stationaer-001.html"
      }],
      "reference" : {
        "reference" : "Encounter/encounter-stationaer-001"
      },
      "name" : "Stationärer Aufenthalt zur Gentherapie",
      "description" : "Stationäre Aufnahme für Gentherapie",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-mii-ext-seltene-syndrome-category.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-ext-seltene-syndrome-category"
      },
      "name" : "Syndrome Category Extension",
      "description" : "Extension to categorize syndrome types for rare diseases (genetic, metabolic, developmental, etc.)",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-mii-vs-seltene-syndrome-category.html"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-seltene-syndrome-category"
      },
      "name" : "Syndrome Category Value Set",
      "description" : "Categories for classifying syndrome types in rare diseases",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-mii-exa-seltene-taillenumfang.html"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-seltene-taillenumfang"
      },
      "name" : "Taillenumfang Beispiel",
      "description" : "Beispiel einer Taillenumfang-Messung bei einem Patienten mit seltener Erkrankung.",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-taillenumfang"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CarePlan"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CarePlan-mii-exa-seltene-therapieplan.html"
      }],
      "reference" : {
        "reference" : "CarePlan/mii-exa-seltene-therapieplan"
      },
      "name" : "Therapieplan Example",
      "description" : "Example of a Therapieplan for a patient.",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-therapieplan"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-symptom-chest-pain.html"
      }],
      "reference" : {
        "reference" : "Observation/symptom-chest-pain"
      },
      "name" : "Thoraxschmerzen",
      "description" : "Akute Thoraxschmerzen als Präsentationssymptom",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-observation-plt-001.html"
      }],
      "reference" : {
        "reference" : "Observation/observation-plt-001"
      },
      "name" : "Thrombozytenzahl - Post-therapeutisch",
      "description" : "Thrombozytenzahl nach Gentherapie",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-observation-troponin-003.html"
      }],
      "reference" : {
        "reference" : "Observation/observation-troponin-003"
      },
      "name" : "Troponin T hs - 01.08.2024",
      "description" : "Troponin T hochsensitiv nach Therapie",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-observation-troponin-004.html"
      }],
      "reference" : {
        "reference" : "Observation/observation-troponin-004"
      },
      "name" : "Troponin T hs - 12.08.2024",
      "description" : "Troponin T hochsensitiv bei Nachsorge",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-observation-troponin-001.html"
      }],
      "reference" : {
        "reference" : "Observation/observation-troponin-001"
      },
      "name" : "Troponin T hs - 22.07.2024",
      "description" : "Troponin T hochsensitiv Baseline",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-observation-troponin-002.html"
      }],
      "reference" : {
        "reference" : "Observation/observation-troponin-002"
      },
      "name" : "Troponin T hs - 28.07.2024",
      "description" : "Troponin T hochsensitiv vor Therapie",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-vsd.html"
      }],
      "reference" : {
        "reference" : "Observation/vsd"
      },
      "name" : "Ventrikelseptumdefekt - HPO-kodiert",
      "description" : "Angeborener Ventrikelseptumdefekt",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-hpo-assessment"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-von-seltene-betroffen-vs.html"
      }],
      "reference" : {
        "reference" : "ValueSet/von-seltene-betroffen-vs"
      },
      "name" : "Von SE betroffen Value Set",
      "description" : "ValueSet zur Angabe ob ein Familienmitglied an der gleichen SE erkrankt ist. Verwendet SNOMED CT codes für internationale Interoperabilität.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-von-seltene-betroffen.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/von-seltene-betroffen"
      },
      "name" : "VonSEBetroffen",
      "description" : "Wird in der MII Modul SE Familienanamnese genutzt um zu bestimmen ob ein Familienmitglied an der gleichen SE erkrankt ist.",
      "exampleBoolean" : false
    }],
    "page" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
        "valueUrl" : "toc.html"
      }],
      "nameUrl" : "toc.html",
      "title" : "Table of Contents",
      "generation" : "html",
      "page" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "index.html"
        }],
        "nameUrl" : "index.html",
        "title" : "Home",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "module-description.html"
        }],
        "nameUrl" : "module-description.html",
        "title" : "Beschreibung des Moduls",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "context.html"
        }],
        "nameUrl" : "context.html",
        "title" : "Kontext und Bezüge zu anderen Modulen",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "scenarios.html"
        }],
        "nameUrl" : "scenarios.html",
        "title" : "Anwendungsszenarien",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "datasets.html"
        }],
        "nameUrl" : "datasets.html",
        "title" : "Datensätze und Beschreibungen",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "information-model.html"
        }],
        "nameUrl" : "information-model.html",
        "title" : "Informationsmodell (UML)",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "profiles-overview.html"
        }],
        "nameUrl" : "profiles-overview.html",
        "title" : "FHIR-Profile (Übersicht)",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "terminology.html"
        }],
        "nameUrl" : "terminology.html",
        "title" : "Terminologien",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "capability.html"
        }],
        "nameUrl" : "capability.html",
        "title" : "CapabilityStatement",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "clinical-genetic-diagnosis-guide.html"
        }],
        "nameUrl" : "clinical-genetic-diagnosis-guide.html",
        "title" : "Leitfaden Klinisch-genetische Diagnose",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "coding-best-practices.html"
        }],
        "nameUrl" : "coding-best-practices.html",
        "title" : "Kodier-Empfehlungen",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "sma-example-annotations.html"
        }],
        "nameUrl" : "sma-example-annotations.html",
        "title" : "Beispiel Spinale Muskelatrophie (SMA)",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "marfan-example-annotations.html"
        }],
        "nameUrl" : "marfan-example-annotations.html",
        "title" : "Beispiel Marfan-Syndrom",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "references.html"
        }],
        "nameUrl" : "references.html",
        "title" : "Referenzen",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "release-notes.html"
        }],
        "nameUrl" : "release-notes.html",
        "title" : "Release Notes",
        "generation" : "markdown"
      }]
    },
    "parameter" : [{
      "code" : "path-resource",
      "value" : "input/capabilities"
    },
    {
      "code" : "path-resource",
      "value" : "input/examples"
    },
    {
      "code" : "path-resource",
      "value" : "input/extensions"
    },
    {
      "code" : "path-resource",
      "value" : "input/models"
    },
    {
      "code" : "path-resource",
      "value" : "input/operations"
    },
    {
      "code" : "path-resource",
      "value" : "input/profiles"
    },
    {
      "code" : "path-resource",
      "value" : "input/resources"
    },
    {
      "code" : "path-resource",
      "value" : "input/vocabulary"
    },
    {
      "code" : "path-resource",
      "value" : "input/maps"
    },
    {
      "code" : "path-resource",
      "value" : "input/testing"
    },
    {
      "code" : "path-resource",
      "value" : "input/history"
    },
    {
      "code" : "path-resource",
      "value" : "fsh-generated/resources"
    },
    {
      "code" : "path-pages",
      "value" : "template/config"
    },
    {
      "code" : "path-pages",
      "value" : "input/assets"
    },
    {
      "code" : "path-pages",
      "value" : "input/images"
    },
    {
      "code" : "path-tx-cache",
      "value" : "input-cache/txcache"
    }]
  }
}

```
