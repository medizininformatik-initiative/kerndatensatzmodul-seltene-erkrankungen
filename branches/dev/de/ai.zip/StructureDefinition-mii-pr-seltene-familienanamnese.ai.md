# MII PR SE Familienanamnese - MII IG Kerndatensatz-Modul Seltene Erkrankungen v2027.0.0-ballot

* [**Inhaltsverzeichnis**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **MII PR SE Familienanamnese**

## Ressourcenprofil: MII PR SE Familienanamnese 

| | |
| :--- | :--- |
| *Offizielle URL*:https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-familienanamnese | *Version*:2027.0.0-ballot |
| Active Stand: 2026-09-14 | *Maschinenlesbarer Name*:MII_PR_Seltene_Familienanamnese |

 

| | | |
| :--- | :--- | :--- |
| Dieses Profil beschreibt die Familienanamnese eines Patienten im Kontext von seltenen Erkrankungen, basierend auf dem MolGen Familienanamnese Profil. Für jedes Familienmitglied wird eine separate FamilyMemberHistory-Ressource erstellt. Das Profil unterstützt die Dokumentation von Todesfällen durch seltene Erkrankungen über condition.contributedToDeath. Für den Indexpatienten selbst kann relationship.coding[snomed] = 116154003 | Patient | verwendet werden, um den Tod des Patienten durch eine seltene Erkrankung einheitlich zu dokumentieren. |

 

Dieses Profil beschreibt die Familienanamnese im Kontext Seltener Erkrankungen. Es ermöglicht die strukturierte Erfassung von Erkrankungen bei Familienmitgliedern, insbesondere mit Fokus auf genetische und erbliche Komponenten seltener Erkrankungen.

**Wichtig:** Für **jedes Familienmitglied** wird eine **separate FamilyMemberHistory-Ressource** erstellt. Ein Familienmitglied kann mehrere Erkrankungen haben, die alle in derselben Ressource unter `condition` dokumentiert werden. Für die Dokumentation des **Todes des Indexpatienten** durch eine seltene Erkrankung kann ebenfalls eine FamilyMemberHistory-Ressource mit `relationship.coding[snomed] = 116154003 | Patient |` erstellt werden (siehe Abschnitt "Für den Indexpatienten" unten).

### Klinische Bedeutung

Die Familienanamnese ist bei seltenen Erkrankungen von besonderer Bedeutung, da viele dieser Erkrankungen eine genetische Komponente aufweisen. Die strukturierte Erfassung ermöglicht:

* Identifikation familiärer Häufungen
* Einschätzung des Vererbungsmusters
* Risikostratifizierung für Angehörige
* Planung genetischer Beratung und Testung

### Tod durch seltene Erkrankung

Die Dokumentation, ob eine Erkrankung zum Tod beigetragen hat, erfolgt über das Standard-FHIR-Element `FamilyMemberHistory.condition.contributedToDeath`. Dieses boolesche Element ist MustSupport und ermöglicht eine klare Zuordnung zwischen einer spezifischen Erkrankung und dem Todesfall.

#### Für Familienmitglieder

Dokumentieren Sie den Tod eines Familienmitglieds durch eine seltene Erkrankung wie folgt:

* `relationship`: Verwandtschaftsverhältnis (z.B. Vater, Mutter, Geschwister)
* `deceased[x]`: Todeszeitpunkt oder -alter
* `condition.code`: Die seltene Erkrankung mit ICD-10-GM, ORPHAcodes oder SNOMED CT
* `condition.contributedToDeath = true`: Kennzeichnung, dass diese Erkrankung zum Tod beitrug

#### Für den Indexpatienten

Das FamilyMemberHistory-Profil kann auch zur Dokumentation des **Todes des Indexpatienten** durch eine seltene Erkrankung verwendet werden:

* `relationship.coding[snomed]`: Setzen Sie auf `116154003 | Patient |` (verfügbar im MolGen ValueSet)
* `patient`: Referenz auf den Indexpatienten selbst
* `deceased[x]`: Todeszeitpunkt oder -alter des Patienten
* `condition.code`: Die seltene Erkrankung, die zum Tod führte
* `condition.contributedToDeath = true`

Diese Modellierung ermöglicht eine einheitliche Dokumentation von Todesfällen durch seltene Erkrankungen für Familienmitglieder und den Patienten selbst, ohne das Patient-Profil erweitern zu müssen.

#### Beispiel

```
{
  "resourceType": "FamilyMemberHistory",
  "status": "completed",
  "patient": {"reference": "Patient/example"},
  "relationship": {
    "coding": [{
      "system": "http://snomed.info/sct",
      "code": "72705000",
      "display": "Mother"
    }]
  },
  "deceasedAge": {"value": 52, "unit": "a", "system": "http://unitsofmeasure.org"},
  "condition": [{
    "code": {
      "coding": [{
        "system": "http://www.orpha.net",
        "code": "558",
        "display": "Marfan-Syndrom"
      }]
    },
    "contributedToDeath": true
  }]
}

```

### MONDO Kodierung (Sekundäre Harmonisierungsontologie)

> **Hinweis:** MONDO ist eine **sekundäre Harmonisierungsontologie** und kein primäres Diagnoseziel. Die primäre Kodierung der Familienerkrankung erfolgt über ICD-10-GM, Alpha-ID, SNOMED CT oder ORPHAcodes. MONDO-Codes können **optional ergänzend** in `condition.code.coding[mondo]` angegeben werden.

MONDO (Monarch Disease Ontology) harmonisiert verschiedene Klassifikationen und ermöglicht die Integration mit internationalen Standards wie [Phenopackets](https://phenopacket-schema.readthedocs.io/) und GA4GH. Weitere Informationen finden sich unter [Terminologien](code-systems.md).

-------

### Mapping Logisches Datenmodell zu FHIR

Das folgende Mapping zeigt die Elemente der Familienanamnese aus dem logischen Datenmodell für Seltene Erkrankungen:

### Zuordnung zu FHIR-Elementen

Die Elemente des logischen Datenmodells werden wie folgt auf das FamilyMemberHistory-Profil abgebildet:

| | | |
| :--- | :--- | :--- |
| `familienanamnese.verwandtschaftsverhaeltnis` | FamilyMemberHistory.relationship | Biologisches Verwandtschaftsverhältnis zum Indexpatienten |
| `familienanamnese.geschlecht` | FamilyMemberHistory.sex | Geschlecht des Familienmitglieds |
| `familienanamnese.gleicheSE` | FamilyMemberHistory.condition.code | Wenn Code identisch mit Indexpatient-Diagnose |
| `familienanamnese.andereSE` | FamilyMemberHistory.condition.code | Wenn Code unterschiedlich zur Indexpatient-Diagnose |
| `familienanamnese.penetranz` | FamilyMemberHistory.condition.extension:penetranz | Extension für fehlende klinische Penetranz trotz genetischer Diagnose bei Familienmitgliedern |
| `familienanamnese.familienmitgliedVerstorben` | FamilyMemberHistory.deceased[x] | Vitalstatus des Familienmitglieds |
| `familienanamnese.todDurchSE` | FamilyMemberHistory.condition.contributedToDeath | Gibt an, ob die Erkrankung zum Tod beigetragen hat |
| `familienanamnese.dokumentationsdatum` | FamilyMemberHistory.date | Datum der Erhebung beziehungsweise Dokumentation |
| `familienanamnese.konsanguinitaetEltern` | Observation (`mii-pr-seltene-consanguinity`) | Blutsverwandtschaft der Eltern; eigenes Profil, nicht Teil der FamilyMemberHistory |

-------

**Suchparameter** sind modulweit im [CapabilityStatement](CapabilityStatement-mii-cps-seltene-capabilitystatement.md) deklariert — dort maschinenlesbar und vollständig, statt je Profil von Hand wiederholt.

Beispielinstanzen sind auf der Profilseite im Abschnitt „Examples" verlinkt.

**Usages:**

* Refer to this Profile: [MII PR SE Consanguinity](StructureDefinition-mii-pr-seltene-consanguinity.md)
* Examples for this Profile: [FamilyMemberHistory/mii-exa-seltene-familienanamnese](FamilyMemberHistory-mii-exa-seltene-familienanamnese.md) and [FamilyMemberHistory/mii-exa-seltene-family-history-001](FamilyMemberHistory-mii-exa-seltene-family-history-001.md)
* CapabilityStatements using this Profile: [MII CPS Seltene Erkrankungen CapabilityStatement](CapabilityStatement-mii-cps-seltene-capabilitystatement.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/de.medizininformatikinitiative.kerndatensatz.seltene|current/StructureDefinition/StructureDefinition-mii-pr-seltene-familienanamnese.json)

### Formale Ansichten des Profilinhalts

 [Beschreibung von Profilen, Differentials, Snapshots und deren Repräsentationen](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Schlüsselelemente-Tabelle](#tabs-key) 
*  [Differential-Tabelle](#tabs-diff) 
*  [Snapshot-Tabelle](#tabs-snap) 
*  [Statistiken/Referenzen](#tabs-summ) 
*  [Alle](#tabs-all) 

#### Terminology Bindings

#### Constraints

Diese Struktur ist abgeleitet von [MII_PR_MolGen_Familienanamnese](https://medizininformatik-initiative.github.io/kerndatensatzmodul-GenetischeTests/2027.0.0-ballot.1/StructureDefinition-mii-pr-molgen-familienanamnese.html) 

#### Terminology Bindings

#### Constraints

Diese Struktur ist abgeleitet von [MII_PR_MolGen_Familienanamnese](https://medizininformatik-initiative.github.io/kerndatensatzmodul-GenetischeTests/2027.0.0-ballot.1/StructureDefinition-mii-pr-molgen-familienanamnese.html) 

** Summary **

Mandatory: 2 elements(2 nested mandatory elements)
 Must-Support: 9 elements

**Extensions**

This structure refers to these extensions:

* [https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-ex-seltene-von-se-betroffen](StructureDefinition-mii-ex-seltene-von-se-betroffen.md)
* [https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-ex-seltene-penetrance](StructureDefinition-mii-ex-seltene-penetrance.md)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of FamilyMemberHistory.deceased[x]
* The element 1 is sliced based on the value of FamilyMemberHistory.condition.onset[x]

 **Schlüsselelemente-Ansicht** 

#### Terminology Bindings

#### Constraints

 **Differential-Ansicht** 

Diese Struktur ist abgeleitet von [MII_PR_MolGen_Familienanamnese](https://medizininformatik-initiative.github.io/kerndatensatzmodul-GenetischeTests/2027.0.0-ballot.1/StructureDefinition-mii-pr-molgen-familienanamnese.html) 

 **Snapshot-AnsichtView** 

#### Terminology Bindings

#### Constraints

Diese Struktur ist abgeleitet von [MII_PR_MolGen_Familienanamnese](https://medizininformatik-initiative.github.io/kerndatensatzmodul-GenetischeTests/2027.0.0-ballot.1/StructureDefinition-mii-pr-molgen-familienanamnese.html) 

** Summary **

Mandatory: 2 elements(2 nested mandatory elements)
 Must-Support: 9 elements

**Extensions**

This structure refers to these extensions:

* [https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-ex-seltene-von-se-betroffen](StructureDefinition-mii-ex-seltene-von-se-betroffen.md)
* [https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-ex-seltene-penetrance](StructureDefinition-mii-ex-seltene-penetrance.md)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of FamilyMemberHistory.deceased[x]
* The element 1 is sliced based on the value of FamilyMemberHistory.condition.onset[x]

 

Weitere Repräsentationen des Profils: [CSV](../StructureDefinition-mii-pr-seltene-familienanamnese.csv), [Excel](../StructureDefinition-mii-pr-seltene-familienanamnese.xlsx), [Schematron](../StructureDefinition-mii-pr-seltene-familienanamnese.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "mii-pr-seltene-familienanamnese",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-shareablestructuredefinition",
    "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-publishablestructuredefinition"]
  },
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-knowledgeCapability",
    "valueCode" : "shareable"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-knowledgeCapability",
    "valueCode" : "publishable"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-usage",
    "valueMarkdown" : "Use this profile as the technical FHIR representation of the corresponding Medical Informatics Initiative logical model. The profile constrains a base FHIR resource for the MII module context by specifying how elements are used, which elements are required or not used, which extensions and terminology bindings apply, and how the resource maps to the module-specific content model. Implementers should produce and consume resource instances that conform to this profile when exchanging data for the corresponding MII module."
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-versionPolicy",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/artifact-version-policy-codes",
        "version" : "3.0.0",
        "code" : "package",
        "display" : "Package"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-topic",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "http://ncicb.nci.nih.gov/xml/owl/EVS/Thesaurus.owl",
        "code" : "C17457"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-author",
    "valueContactDetail" : {
      "telecom" : [{
        "system" : "email",
        "value" : "thomas.debertshaeuser@charite.de"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-editor",
    "valueContactDetail" : {
      "name" : "Taskforce Core Data Set"
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-reviewer",
    "valueContactDetail" : {
      "name" : "Interoperability Working Group",
      "telecom" : [{
        "system" : "url",
        "value" : "https://www.medizininformatik-initiative.de/en/collaboration/interoperability-working-group"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-reviewer",
    "valueContactDetail" : {
      "name" : "National Steering Committee",
      "telecom" : [{
        "system" : "url",
        "value" : "https://www.medizininformatik-initiative.de/en/collaboration/national-steering-committee"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-endorser",
    "valueContactDetail" : {
      "name" : "Interoperability Working Group",
      "telecom" : [{
        "system" : "url",
        "value" : "https://www.medizininformatik-initiative.de/en/collaboration/interoperability-working-group"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-endorser",
    "valueContactDetail" : {
      "name" : "National Steering Committee",
      "telecom" : [{
        "system" : "url",
        "value" : "https://www.medizininformatik-initiative.de/en/collaboration/national-steering-committee"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-versionAlgorithm",
    "valueCoding" : {
      "system" : "http://hl7.org/fhir/version-algorithm",
      "code" : "semver",
      "display" : "SemVer"
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/resource-approvalDate",
    "valueDate" : "2026-09-15"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/resource-effectivePeriod",
    "valuePeriod" : {
      "start" : "2027"
    }
  }],
  "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-familienanamnese",
  "version" : "2027.0.0-ballot",
  "name" : "MII_PR_Seltene_Familienanamnese",
  "title" : "MII PR SE Familienanamnese",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-09-14T18:57:54+00:00",
  "publisher" : "Medizininformatik Initiative",
  "_publisher" : {
    "extension" : [{
      "extension" : [{
        "url" : "lang",
        "valueCode" : "de"
      },
      {
        "url" : "content",
        "valueString" : "Medizininformatik Initiative"
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/translation"
    }]
  },
  "contact" : [{
    "name" : "Medizininformatik Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de/"
    }]
  }],
  "description" : "Dieses Profil beschreibt die Familienanamnese eines Patienten im Kontext von seltenen Erkrankungen, basierend auf dem MolGen Familienanamnese Profil. Für jedes Familienmitglied wird eine separate FamilyMemberHistory-Ressource erstellt. Das Profil unterstützt die Dokumentation von Todesfällen durch seltene Erkrankungen über condition.contributedToDeath. Für den Indexpatienten selbst kann relationship.coding[snomed] = 116154003 | Patient | verwendet werden, um den Tod des Patienten durch eine seltene Erkrankung einheitlich zu dokumentieren.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "SE-LogicalModel",
    "uri" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/LogicalModel/Seltene",
    "name" : "Mapping FHIR zu Seltene Erkrankungen Logical Model"
  },
  {
    "identity" : "MII-KDS",
    "name" : "MII KDS Mapping"
  },
  {
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "FamilyMemberHistory",
  "baseDefinition" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-molgen/StructureDefinition/familienanamnese",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "FamilyMemberHistory",
      "path" : "FamilyMemberHistory",
      "mapping" : [{
        "identity" : "SE-LogicalModel",
        "map" : "familienanamnese",
        "comment" : "Familienanamnese"
      }]
    },
    {
      "id" : "FamilyMemberHistory.extension",
      "path" : "FamilyMemberHistory.extension",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "url"
        }],
        "ordered" : false,
        "rules" : "open"
      },
      "min" : 1
    },
    {
      "id" : "FamilyMemberHistory.extension:vonSEBetroffen",
      "path" : "FamilyMemberHistory.extension",
      "sliceName" : "vonSEBetroffen",
      "short" : "Gibt an, ob das Familienmitglied von der gleichen seltenen Erkrankung betroffen ist",
      "definition" : "Extension zur Angabe, ob ein Familienmitglied von der gleichen seltenen Erkrankung betroffen ist wie der Patient",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-ex-seltene-von-se-betroffen"]
      }],
      "mustSupport" : true,
      "mapping" : [{
        "identity" : "SE-LogicalModel",
        "map" : "familienanamnese.gleicheSE",
        "comment" : "Gleiche SE"
      }]
    },
    {
      "id" : "FamilyMemberHistory.patient",
      "path" : "FamilyMemberHistory.patient",
      "mapping" : [{
        "identity" : "SE-LogicalModel",
        "map" : "persoenlicheInfosIndexpatient",
        "comment" : "Patient/Indexpatient"
      }]
    },
    {
      "id" : "FamilyMemberHistory.date",
      "path" : "FamilyMemberHistory.date",
      "mapping" : [{
        "identity" : "SE-LogicalModel",
        "map" : "familienanamnese.dokumentationsdatum",
        "comment" : "Datum der Familienanamnese"
      }]
    },
    {
      "id" : "FamilyMemberHistory.relationship",
      "path" : "FamilyMemberHistory.relationship",
      "mapping" : [{
        "identity" : "SE-LogicalModel",
        "map" : "familienanamnese.verwandtschaftsverhaeltnis",
        "comment" : "Verwandtschaftsverhältnis"
      }]
    },
    {
      "id" : "FamilyMemberHistory.sex",
      "path" : "FamilyMemberHistory.sex",
      "mapping" : [{
        "identity" : "SE-LogicalModel",
        "map" : "familienanamnese.geschlecht",
        "comment" : "Geschlecht"
      }]
    },
    {
      "id" : "FamilyMemberHistory.born[x]",
      "path" : "FamilyMemberHistory.born[x]",
      "mustSupport" : true
    },
    {
      "id" : "FamilyMemberHistory.age[x]",
      "path" : "FamilyMemberHistory.age[x]",
      "mustSupport" : true
    },
    {
      "id" : "FamilyMemberHistory.deceased[x]",
      "path" : "FamilyMemberHistory.deceased[x]",
      "slicing" : {
        "discriminator" : [{
          "type" : "type",
          "path" : "$this"
        }],
        "ordered" : false,
        "rules" : "open"
      },
      "mustSupport" : true
    },
    {
      "id" : "FamilyMemberHistory.deceased[x]:deceasedBoolean",
      "path" : "FamilyMemberHistory.deceased[x]",
      "sliceName" : "deceasedBoolean",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }],
      "mapping" : [{
        "identity" : "SE-LogicalModel",
        "map" : "familienanamnese.familienmitgliedVerstorben",
        "comment" : "Familienmitglied verstorben"
      }]
    },
    {
      "id" : "FamilyMemberHistory.deceased[x]:deceasedDate",
      "path" : "FamilyMemberHistory.deceased[x]",
      "sliceName" : "deceasedDate",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "date"
      }],
      "mapping" : [{
        "identity" : "SE-LogicalModel",
        "map" : "familienanamnese.familienmitgliedVerstorben",
        "comment" : "Sterbedatum"
      }]
    },
    {
      "id" : "FamilyMemberHistory.deceased[x]:deceasedAge",
      "path" : "FamilyMemberHistory.deceased[x]",
      "sliceName" : "deceasedAge",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Age"
      }],
      "mapping" : [{
        "identity" : "SE-LogicalModel",
        "map" : "familienanamnese.familienmitgliedVerstorben",
        "comment" : "Alter bei Tod"
      }]
    },
    {
      "id" : "FamilyMemberHistory.reasonCode",
      "path" : "FamilyMemberHistory.reasonCode",
      "mapping" : [{
        "identity" : "SE-LogicalModel",
        "map" : "familienanamnese.andereSE",
        "comment" : "Grund/Erkrankung des Familienmitglieds"
      }]
    },
    {
      "id" : "FamilyMemberHistory.condition.extension",
      "path" : "FamilyMemberHistory.condition.extension",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "url"
        }],
        "ordered" : false,
        "rules" : "open"
      }
    },
    {
      "id" : "FamilyMemberHistory.condition.extension:penetrance",
      "path" : "FamilyMemberHistory.condition.extension",
      "sliceName" : "penetrance",
      "short" : "Penetranz der genetischen Variante beim Familienmitglied",
      "definition" : "Angabe zur Penetranz der genetischen Variante bei der Erkrankung des Familienmitglieds",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-ex-seltene-penetrance"]
      }],
      "mustSupport" : true,
      "mapping" : [{
        "identity" : "SE-LogicalModel",
        "map" : "familienanamnese.penetranz",
        "comment" : "Penetranz"
      }]
    },
    {
      "id" : "FamilyMemberHistory.condition.code.coding:icd10-gm",
      "path" : "FamilyMemberHistory.condition.code.coding",
      "sliceName" : "icd10-gm",
      "mapping" : [{
        "identity" : "SE-LogicalModel",
        "map" : "familienanamnese.andereSE",
        "comment" : "Andere SE (ICD-10-GM)"
      }]
    },
    {
      "id" : "FamilyMemberHistory.condition.code.coding:sct",
      "path" : "FamilyMemberHistory.condition.code.coding",
      "sliceName" : "sct",
      "mapping" : [{
        "identity" : "SE-LogicalModel",
        "map" : "familienanamnese.andereSE",
        "comment" : "Andere SE (SNOMED CT)"
      }]
    },
    {
      "id" : "FamilyMemberHistory.condition.code.coding:orphanet",
      "path" : "FamilyMemberHistory.condition.code.coding",
      "sliceName" : "orphanet",
      "mapping" : [{
        "identity" : "SE-LogicalModel",
        "map" : "familienanamnese.andereSE",
        "comment" : "Andere SE (Orpha-Code)"
      }]
    },
    {
      "id" : "FamilyMemberHistory.condition.code.coding:mondo",
      "path" : "FamilyMemberHistory.condition.code.coding",
      "sliceName" : "mondo",
      "short" : "MONDO Code für die Erkrankung",
      "definition" : "Monarch Disease Ontology (MONDO) Code für internationale Interoperabilität. MONDO harmonisiert SNOMED, ORDO, OMIM und ICD automatisch.",
      "min" : 0,
      "max" : "1",
      "patternCoding" : {
        "system" : "http://purl.obolibrary.org/obo/mondo.owl"
      },
      "mustSupport" : true
    },
    {
      "id" : "FamilyMemberHistory.condition.code.coding:mondo.system",
      "path" : "FamilyMemberHistory.condition.code.coding.system",
      "min" : 1
    },
    {
      "id" : "FamilyMemberHistory.condition.code.coding:mondo.code",
      "path" : "FamilyMemberHistory.condition.code.coding.code",
      "min" : 1
    },
    {
      "id" : "FamilyMemberHistory.condition.code.coding:mondo.display",
      "path" : "FamilyMemberHistory.condition.code.coding.display",
      "mustSupport" : true
    },
    {
      "id" : "FamilyMemberHistory.condition.contributedToDeath",
      "path" : "FamilyMemberHistory.condition.contributedToDeath",
      "short" : "Tod durch diese Erkrankung",
      "definition" : "Gibt an, ob diese Erkrankung zum Tod des Familienmitglieds beigetragen hat. Relevant für die Dokumentation von Todesfällen durch seltene Erkrankungen in der Familie.",
      "mustSupport" : true,
      "mapping" : [{
        "identity" : "SE-LogicalModel",
        "map" : "familienanamnese.todDurchSE",
        "comment" : "Tod durch seltene Erkrankung"
      }]
    },
    {
      "id" : "FamilyMemberHistory.condition.onset[x]",
      "path" : "FamilyMemberHistory.condition.onset[x]",
      "slicing" : {
        "discriminator" : [{
          "type" : "type",
          "path" : "$this"
        }],
        "ordered" : false,
        "rules" : "open"
      },
      "mustSupport" : true
    },
    {
      "id" : "FamilyMemberHistory.condition.onset[x]:onsetAge",
      "path" : "FamilyMemberHistory.condition.onset[x]",
      "sliceName" : "onsetAge",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Age"
      }],
      "mapping" : [{
        "identity" : "SE-LogicalModel",
        "map" : "Alter bei Erkrankungsbeginn",
        "comment" : "Alter bei Erkrankung"
      }]
    }]
  }
}

```
