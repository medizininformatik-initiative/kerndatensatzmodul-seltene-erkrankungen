# Familienanamnese - Urgroßmutter mit Muskelerkrankung - MII IG Kerndatensatz-Modul Seltene Erkrankungen v2027.0.0-ballot

* [**Inhaltsverzeichnis**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **Familienanamnese - Urgroßmutter mit Muskelerkrankung**

## Beispiel FamilyMemberHistory: Familienanamnese - Urgroßmutter mit Muskelerkrankung

-------

**German**

-------

Profile: [MII PR SE Familienanamnese](StructureDefinition-mii-pr-seltene-familienanamnese.md) version: 2027.0.0-ballot

**MII EX SE Von SE betroffen**: Unknown

**status**: Completed

**patient**: [Anonymous Patient Female, DoB: 2024-07-01 ( https://www.medizininformatik-initiative.de/fhir/sid/patient-id#SMA-2024-001)](Patient-mii-exa-seltene-patient-sma-001.md)

**date**: 2024-07-22

**relationship**: Great grandmother

### Conditions

| | |
| :--- | :--- |
| - | **Code** |
| * | Unbekannte Muskelerkrankung |



## Resource Content

```json
{
  "resourceType" : "FamilyMemberHistory",
  "id" : "mii-exa-seltene-family-history-001",
  "meta" : {
    "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-familienanamnese|2027.0.0-ballot"]
  },
  "extension" : [{
    "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-ex-seltene-von-se-betroffen",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "http://snomed.info/sct",
        "code" : "261665006",
        "display" : "Unknown"
      }]
    }
  }],
  "status" : "completed",
  "patient" : {
    "reference" : "Patient/mii-exa-seltene-patient-sma-001"
  },
  "date" : "2024-07-22",
  "relationship" : {
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "78652007",
      "display" : "Great grandmother"
    }]
  },
  "condition" : [{
    "code" : {
      "coding" : [{
        "system" : "http://snomed.info/sct",
        "code" : "129565002",
        "display" : "Disorder of muscle"
      }],
      "text" : "Unbekannte Muskelerkrankung"
    }
  }]
}

```
