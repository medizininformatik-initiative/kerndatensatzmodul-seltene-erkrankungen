# Marfan-Syndrom - Klinische Diagnose - MII IG Kerndatensatz-Modul Seltene Erkrankungen v2027.0.0-ballot

* [**Inhaltsverzeichnis**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **Marfan-Syndrom - Klinische Diagnose**

## Beispiel Condition: Marfan-Syndrom - Klinische Diagnose

-------

**German**

-------

Profil: [MII PR SE Clinical Diagnosis](StructureDefinition-mii-pr-seltene-clinical-diagnosis.md) version: 2027.0.0-ballot

**Condition Asserted Date**: 2024-12-15

**clinicalStatus**: Active

**verificationStatus**: Provisional

**category**: Encounter Diagnosis

**code**: Marfan-Syndrom, klinisch diagnostiziert

**subject**: [Max Mustermann (official) Male, DoB: 1990-01-01 ( http://test-krankenhaus.de/fhir/sid/patienten#12345)](Patient-mii-exa-seltene-patient.md)

**encounter**: [Encounter: status = finished; class = ambulatory (ActCode#AMB); type = Seen in cardiac clinic (finding); period = 2024-12-15 --> 2024-12-15](Encounter-mii-exa-seltene-encounter-cardiology-consultation.md)

**onset**: 14 years (Details: UCUM codea = 'a')

**recordedDate**: 2024-12-15

> **evidence****code**: Aortenwurzeldilatation**detail**: [Observation Aortenwurzeldilatation](Observation-mii-exa-seltene-aortic-root-dilatation.md)

> **evidence****code**: Linsenluxation**detail**: [Observation Linsenluxation](Observation-mii-exa-seltene-lens-dislocation.md)

> **evidence****code**: Hochwuchs**detail**: [Observation Hochwuchs](Observation-mii-exa-seltene-tall-stature.md)

> **evidence****code**: Arachnodaktylie**detail**: [Observation Arachnodaktylie](Observation-mii-exa-seltene-arachnodactyly.md)

**note**: 

> 

Klinische Diagnose basierend auf Ghent-Kriterien. Patient erfüllt Major-Kriterien in kardiovaskulärem und ophthalmologischem System. Genetische Testung wird veranlasst.




## Resource Content

```json
{
  "resourceType" : "Condition",
  "id" : "mii-exa-seltene-example-marfan-clinical-diagnosis",
  "meta" : {
    "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-clinical-diagnosis|2027.0.0-ballot"]
  },
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/condition-assertedDate",
    "valueDateTime" : "2024-12-15"
  }],
  "clinicalStatus" : {
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/condition-clinical",
      "code" : "active"
    }]
  },
  "verificationStatus" : {
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/condition-ver-status",
      "code" : "provisional"
    }]
  },
  "category" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/condition-category",
      "code" : "encounter-diagnosis"
    }]
  }],
  "code" : {
    "coding" : [{
      "system" : "http://omim.org",
      "version" : "2024",
      "code" : "154700",
      "display" : "Marfan syndrome"
    },
    {
      "system" : "http://snomed.info/sct",
      "code" : "19346006",
      "display" : "Marfan syndrome"
    },
    {
      "system" : "http://www.orpha.net",
      "code" : "558",
      "display" : "Marfan syndrome"
    }],
    "text" : "Marfan-Syndrom, klinisch diagnostiziert"
  },
  "subject" : {
    "reference" : "Patient/mii-exa-seltene-patient"
  },
  "encounter" : {
    "reference" : "Encounter/mii-exa-seltene-encounter-cardiology-consultation"
  },
  "onsetAge" : {
    "value" : 14,
    "unit" : "years",
    "system" : "http://unitsofmeasure.org",
    "code" : "a"
  },
  "recordedDate" : "2024-12-15",
  "evidence" : [{
    "code" : [{
      "coding" : [{
        "system" : "http://human-phenotype-ontology.org",
        "code" : "HP:0002616",
        "display" : "Aortic root aneurysm"
      }],
      "text" : "Aortenwurzeldilatation"
    }],
    "detail" : [{
      "reference" : "Observation/mii-exa-seltene-aortic-root-dilatation"
    }]
  },
  {
    "code" : [{
      "coding" : [{
        "system" : "http://human-phenotype-ontology.org",
        "code" : "HP:0001083",
        "display" : "Ectopia lentis"
      }],
      "text" : "Linsenluxation"
    }],
    "detail" : [{
      "reference" : "Observation/mii-exa-seltene-lens-dislocation"
    }]
  },
  {
    "code" : [{
      "coding" : [{
        "system" : "http://human-phenotype-ontology.org",
        "code" : "HP:0000098",
        "display" : "Tall stature"
      }],
      "text" : "Hochwuchs"
    }],
    "detail" : [{
      "reference" : "Observation/mii-exa-seltene-tall-stature"
    }]
  },
  {
    "code" : [{
      "coding" : [{
        "system" : "http://human-phenotype-ontology.org",
        "code" : "HP:0001166",
        "display" : "Arachnodactyly"
      }],
      "text" : "Arachnodaktylie"
    }],
    "detail" : [{
      "reference" : "Observation/mii-exa-seltene-arachnodactyly"
    }]
  }],
  "note" : [{
    "text" : "Klinische Diagnose basierend auf Ghent-Kriterien. Patient erfüllt Major-Kriterien in kardiovaskulärem und ophthalmologischem System. Genetische Testung wird veranlasst."
  }]
}

```
