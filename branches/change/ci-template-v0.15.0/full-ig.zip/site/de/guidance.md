# Anleitung - MII IG Kerndatensatz-Modul Seltene Erkrankungen v2027.0.0-ballot

* [**Inhaltsverzeichnis**](toc.md)
* **Anleitung**

## Anleitung

Diese Seite enthält Übersetzungen aus der Originalsprache, in der der Leitfaden verfasst wurde. Informationen zu diesen Übersetzungen und Anweisungen zum Abgeben von Feedback zu den Übersetzungen finden Sie [hier](translationinfo.md).

Im vorliegenden IG wird daraus abgeleitet, nach europäischem Datensatz ([CDS-ERDRI.eu](https://eu-rd-platform.jrc.ec.europa.eu/sites/default/files/CDS/JRC-2018-00192-00-00-DE-TRA-00-Final.pdf)) und französischen Datensatz ([SDM-MR.fr](https://www.bndmr.fr/les-donnees-collectees/le-set-de-donnees-minimal/)) Vorbild in möglichst vielen Einrichtungen, an möglichst vielen klnischen Arbeitsplätzen für möglichst viele Betroffene von Seltenen Erkrankungen sowie durch Betroffene in eigener Regie die Dokumentation einheitlicher, interoperabler Minimalbasisdatensätze anzustreben.

Diese Minimalbasisdatensätze sollen sowohl lokal als auch übergreifend gemeinsam datenschutzkonform möglichst vielfältig genutzt werden können. Darauf dürfen mit Orientierung an der Gliederung der **Europäischen Referenznetzwerke für Seltene und Komplexe Erkrankungen (ERN)** spezifischere, differenziertere Dokumentationen aufbauen. Die Erhebung und Nutzung soll in ausgewählten Anwendungsszenarien gestaltet und erprobt werden.

> **Written during migration - review before release.** Weiterführende Leitfäden dieses Moduls: [Leitfaden: Klinische vs. Genetische Diagnose](clinical-genetic-diagnosis-guide.md) · [Kodier-Empfehlungen bei Seltenen Erkrankungen](coding-best-practices.md)

### Anwendungsszenario der Behandlung einer Seltenen Erkrankung am Beispiel der Spinalen Muskelatrophie (SMA)

**Anamnese**

Bei einem neugeborenen Mädchen wird beim Neugeborenenscreening am 18.07.2024 der Verdacht auf eine **Spinale Muskelatrophie (SMA)** gestellt. Den Eltern wird geraten, sich in einem Zentrum vorzustellen, das auf die Behandlung der SMA spezialisiert ist. Ihnen werden zwei Zentren empfohlen. 
 Bis auf eine unbekannte Muskelerkrankung der Urgroßmutter ist die **Familienanamnese unauffällig**.

**Therapie und Verlauf:**

Die Eltern stellen ihr Kind in einem dieser Zentren am 22.07.2024 ambulant vor. Im Zentrum wird ein Molekulargenetischer Befund im EDTA-Blut am 26.07.2024 erhoben. Dieser ergibt den **molekulargenetischen Nachweis** einer SMA und bestätigt den klinischen Verdacht des Neugeborenenscreenings. Der Befund ergibt im Einzelnen folgendes Ergebnis:

1. 0 Kopien des SMN1-Gens
1. 2 Kopien des SMN2-Gens

Dieses Ergebnis wird als krankheitsursächlich gewertet. Damit wird die am 22.07.2024 dokumentierte Einweisungsdiagnose nach **ICD-10-GM G12.0 „Infantile Spinale Muskelatrophie Typ 1"** bestätigt. Da die Kodierung der Diagnose im Kodiertool im Klinischen Arbeitsplatzsystem (KAS) des Krankenhauses vorgenommen wird, wird zusätzlich der passende **ORPHAcode ORPHA:83330** dokumentiert.

Den Eltern des Kindes wird eine Behandlung mit einem Gentherapeutikum empfohlen; sowie zwei weitere Medikamente als Behandlungsalternativen genannt. Nach einer kurzen Bedenkzeit entscheiden sich die Eltern für die **Behandlung mit dem Gentherapeutikum.**

Das **Gentherapeutikum** wird bei einem stationären Aufenthalt im Zentrum ohne Komplikationen am 29.07.2024 verabreicht mit vorheriger Gabe von Prednisolon. Eine Laboruntersuchung wird standardmäßig bei stationärer Aufnahme durchgeführt. Der weitere Verlauf im Krankenhaus ist unauffällig. Das Labor ist posttherapeutisch bzgl. ALT und AST sowie der Thrombozytenzahl normwertig.

Die SMA wird beim stationären Aufenthalt wiederum mit **G12.0** nach ICD-10-GM und dem ORPHAcode ORPHA:83330 dokumentiert. Die Gentherapie wird als **Prozedur nach SOP** mit dem **Code: 6-00d.0** im KAS dokumentiert.

Bei Entlassung wird den Eltern eine Wiedervorstellung in einer kinderärztlichen Praxis sowie die weitere Durchführung der Therapie mit **Prednisolon** empfohlen. Eine humangenetische Beratung sowie die Vorstellung im Sozialpädiatrischen Zentrum wird veranlasst. Mit den Eltern wird ein patientenbezogener Nachsorgeplan im Zentrum vereinbart.

**Nachsorge**

Beim ersten ambulanten Nachsorgetermin im Zentrum am 12.08.2024 wird die klinische Untersuchung inkl. Labor durchgeführt. Die Werte für ALT und AST sowie die Thrombozytenzahl sind dabei normwertig, aber **Troponin Ths mit 106 ng/l erhöht** – die Verlaufswerte vorher lagen bei 57 ng/l am 01.08.2025, 58 ng/l am 28.07.2025 und 92 ng/l am 22.07.2025. Somit war das Trop T bereits vor der Gentherapie erhöht.

-------

### Anwendungsszenario der Behandlung einer Seltenen Erkrankung am Beispiel des Marfan Syndroms

**Anamnese**

Ein 19-jähriger junger Mann stellt sich ambulant am 15.10.2024 mit Verdacht auf **Katerakt** (Grauer Star) und **Marfan Syndrom** in der Augenklinik eines Universitätsklinikums vor. Mit ihm wird die operative Behandlung des Grauen Stars mittels **Phakoemulsifikation** und der anschließenden **Implantation einer Hinterkammerlinse (HKL)** besprochen. Der Patient willigt ein und daraufhin wird der operative Eingriff am 12.11.2024 komplikationslos durchgeführt. Der postoperative Verlauf gestaltet sich ebenfalls unauffällig. Dem jungen Mann wird geraten, sich im Marfan-Zentrum der Uniklinik bei V. a. Marfan Syndrom vorzustellen.

Der Patient kommt dem ärztlichen Rat nach und stellt sich am 15.12.2024 ambulant dort vor. Er berichtet bei diesem Besuch, dass er etwa 3 Tage zuvor Blut gehustet habe, kein Fieber hat, aber manchmal **Schmerzen im Bereich des Herzens**. Er hat eine **Körpergröße von 2,13 m** und sein **rechtes Bein ist verkürzt**. Der Blutdruck wurde bereits mit **Losartan** eingestellt. Bei der durchgeführten **Echokardiographie** wird eine **dilatierte Aortenwurzel**, eine leichte **Aortenklappen-Insuffizienz** sowie ein anteriorer und posteriorer Mitralklappenprolaps mit geringer **Mitralinsuffizienz** festgestellt. In der Röntgen-Thorax aufnahme zeigt sich zusätzlich eine **Steilstellung der Brustwirbelsäule (BWS)**.

Das Marfan-Zentrum kommt zum Schluss, dass es sich um die Diagnose eines Marfan Syndroms handelt, welche nach der Genter Nosologie bestätigt wurden. Es liegen Hauptmerkmale aus kardiovaskulärer, ophthalmologischer und klinisch-skelettaler Sicht vor." Die Diagnose des Marfan Syndroms wird mit dem **ICD-10-GM-Code: Q87.4** und dem dazugehörigen **ORPHAcode ORPHA:558** verschlüsselt.

Der Patient wird über die Möglichkeit informiert, die Daten über seine Seltene Erkrankung in ein zentrales deutschlandweites **"Nationale Register für Seltene Erkrankungen" (NARSE)** einzutragen. Der Patient willigt ein und unterschreibt die Einwilligungserklärung und seine behandelnde Ärztin nimmmt die Registrierung des Patienten beim NARSE vor und trägt die Krankheitsdaten des Patienten ins Register ein. Neben den Daten zu seiner Anamnese und Diagnose trägt seine Ärztin, die vom Patienten genannten Symptome seiner Erkrankung in Form von [HPO (Human Phenotyp Ontology)](https://hpo.jax.org/) Terms ein. Für die Schmerzen im Bereich des Herzens kodiert sie unter anderem den **HPO-Term HP:0100749** (chest pain) ein.

Das Marfan-Zentrum sieht bei dem Patienten es als absolut lebensnotwendig an, dass der arterielle Blutdruck streng eingestellt und niedrig gehalten wird. Die systolischen Blutdruckwerte sollten 130 mmHg nicht übersteigen und die diastolischen Werte sollten maximal zwischen 80-85 mmHg liegen. Sie haben deshalb damit begonnen, die **Losartan**-Medikation neu einzustellen und raten zu einer engmaschigen Blutdruckkontrolle und auch um eine Kontrolle der Langzeit-Blutdruckmessung. Das Marfan-Zentrum sieht zwar zu diesem Zeitpunkt bereits eine Operationsindikation, da aber der gemessene Aortendurchmesser noch im unteren Grenzbereich liegt, empfiehlt es demzufolge zunächst regelmäßige Kontrollen durchzuführen, und entsprechend die Aortenwurzeloperation zu planen. Der Patient stimmt diesem Vorgehen zu.

**Therapie und Verlauf**

Der geplante Eingriff einer Klappenerhaltender Aorta aszendens Ersatz nach David, **OPS: 5-354.0a** wird am 15.03.2025 durchgeführt.

