# Beispiel Geburtsgewicht - MII IG Kerndatensatz-Modul Seltene Erkrankungen v2027.0.0-ballot.rc1

* [**Inhaltsverzeichnis**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **Beispiel Geburtsgewicht**

## Beispiel Observation: Beispiel Geburtsgewicht

-------

**German**

-------

Profile: [MII PR SE Geburtsgewicht](StructureDefinition-mii-pr-seltene-geburtsgewicht.md) version: 2027.0.0-ballot.rc1

**status**: Final

**category**: Vital Signs

**code**: Birth weight Measured

**subject**: [Anonymous Patient Female, DoB: 2024-07-01 ( https://www.medizininformatik-initiative.de/fhir/sid/patient-id#SMA-2024-001)](Patient-patient-sma-001.md)

**effective**: 2024-07-01

**value**: 3240 Gramm (Details: UCUM codeg = 'g')



## Resource Content

```json
{
  "resourceType" : "Observation",
  "id" : "mii-exa-seltene-geburtsgewicht",
  "meta" : {
    "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-geburtsgewicht|2027.0.0-ballot.rc1"]
  },
  "status" : "final",
  "category" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
      "code" : "vital-signs"
    }]
  }],
  "code" : {
    "coding" : [{
      "system" : "http://loinc.org",
      "code" : "8339-4",
      "display" : "Birth weight Measured"
    }]
  },
  "subject" : {
    "reference" : "Patient/patient-sma-001"
  },
  "effectiveDateTime" : "2024-07-01",
  "valueQuantity" : {
    "value" : 3240,
    "unit" : "Gramm",
    "system" : "http://unitsofmeasure.org",
    "code" : "g"
  }
}

```
