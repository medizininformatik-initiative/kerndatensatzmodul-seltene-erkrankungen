# CapabilityStatements - MII IG Kerndatensatz-Modul Seltene Erkrankungen v2027.0.0-ballot

* [**Inhaltsverzeichnis**](toc.md)
* **CapabilityStatements**

## CapabilityStatements

Das CapabilityStatement definiert die erwarteten Fähigkeiten eines konformen Systems zur Implementierung des Kerndatensatzmoduls Seltene Erkrankungen der Medizininformatik-Initiative.

Canonical: `https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/CapabilityStatement/metadata`

[Link Simplifier Profil Übersicht](https://simplifier.net/resolve?canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/CapabilityStatement/metadata&fhirVersion=R4&scope=de.medizininformatikinitiative.kerndatensatz.seltene@2026.0.0-ballot)

Es beschreibt die verpflichtenden Interaktionen, die ein konformes System unterstützen MUSS, einschließlich:

### Unterstützte Ressourcen

Das System MUSS folgende Ressourcen unterstützen:

* **Condition** - Für klinische und genetische Diagnosen sowie Symptome
* **ClinicalImpression** - Für klinische Beurteilungen und Assessments
* **Observation** - Für HPO-basierte phänotypische Beobachtungen und Vitalparameter
* **ResearchStudy** - Für Studieninformationen
* **ServiceRequest** - Für Studieneinschluss-Anfragen
* **Task** - Für Therapieempfehlungen
* **CarePlan** - Für Therapiepläne
* **FamilyMemberHistory** - Für Familienanamnese

### Unterstützte Interaktionen

Für alle Ressourcen MÜSSEN mindestens folgende Interaktionen unterstützt werden:

* `read` - Lesen einzelner Ressourcen
* `search-type` - Suche nach Ressourcen eines Typs

### Unterstützte Suchparameter

Das System MUSS die im CapabilityStatement definierten Suchparameter für jede Ressource unterstützen, einschließlich:

* Basis-Suchparameter (`_id`, `_lastUpdated`, `_profile`)
* Ressourcen-spezifische Suchparameter (z.B. `code`, `subject`, `encounter`)
* Composite-Suchparameter für komplexe Abfragen

### Konformität

Systeme, die Konformität zu diesem Modul beanspruchen, MÜSSEN:

1. Alle im CapabilityStatement als "SHALL" markierten Anforderungen erfüllen
1. Die definierten Profile für die jeweiligen Ressourcen unterstützen
1. Die spezifizierten Suchparameter implementieren
1. FHIR Version 4.0.1 verwenden

### Vollständiges CapabilityStatement

Das vollständige CapabilityStatement ist in der Artefakt-Übersicht abrufbar (siehe [Artifacts](artifacts.md)).

