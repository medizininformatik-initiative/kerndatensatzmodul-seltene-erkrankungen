# SMA Fallbeispiel - Vollständiges Transaction Bundle - MII IG Kerndatensatz-Modul Seltene Erkrankungen v2027.0.0-ballot.rc1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **SMA Fallbeispiel - Vollständiges Transaction Bundle**

## Example Bundle: SMA Fallbeispiel - Vollständiges Transaction Bundle



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "mii-exa-seltene-bundle-sma-complete",
  "type" : "transaction",
  "timestamp" : "2024-08-12T14:00:00Z",
  "entry" : [{
    "fullUrl" : "urn:uuid:6830d99e-9bbe-48ed-8927-ff28eadc42e0",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "mii-exa-seltene-patient-sma-001",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"Patient_mii-exa-seltene-patient-sma-001\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient mii-exa-seltene-patient-sma-001</b></p><a name=\"mii-exa-seltene-patient-sma-001\"> </a><a name=\"hcmii-exa-seltene-patient-sma-001\"> </a><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Anonymous Patient Female, DoB: 2024-07-01 ( https://www.medizininformatik-initiative.de/fhir/sid/patient-id#SMA-2024-001)</p><hr/></div></div>"
      },
      "identifier" : [{
        "system" : "https://www.medizininformatik-initiative.de/fhir/sid/patient-id",
        "value" : "SMA-2024-001"
      }],
      "gender" : "female",
      "birthDate" : "2024-07-01"
    },
    "request" : {
      "method" : "POST",
      "url" : "Patient"
    }
  },
  {
    "fullUrl" : "urn:uuid:117180a6-0392-47c5-8841-aa5b57d0e47e",
    "resource" : {
      "resourceType" : "Condition",
      "id" : "mii-exa-seltene-condition-sma-suspected",
      "meta" : {
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-clinical-diagnosis|2027.0.0-ballot.rc1"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"Condition_mii-exa-seltene-condition-sma-suspected\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Condition mii-exa-seltene-condition-sma-suspected</b></p><a name=\"mii-exa-seltene-condition-sma-suspected\"> </a><a name=\"hcmii-exa-seltene-condition-sma-suspected\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-mii-pr-seltene-clinical-diagnosis.html\">MII PR SE Clinical Diagnosis</a> version: 2027.0.0-ballot.rc1</p></div><p><b>Condition Asserted Date</b>: 2024-07-18</p><p><b>clinicalStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-clinical active}\">Active</span></p><p><b>verificationStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-ver-status unconfirmed}\">Unconfirmed</span></p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-category encounter-diagnosis}\">Encounter Diagnosis</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 64383006}, {http://human-phenotype-ontology.org HP:0007373}\">Verdacht auf Spinale Muskelatrophie</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-seltene-patient-sma-001.html\">Anonymous Patient Female, DoB: 2024-07-01 ( https://www.medizininformatik-initiative.de/fhir/sid/patient-id#SMA-2024-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-seltene-encounter-screening-001.html\">Encounter: status = finished; class = ambulatory (ActCode#AMB); type = Neonatal screening (procedure); period = 2024-07-18 --&gt; 2024-07-18; reasonCode = </a></p><p><b>recordedDate</b>: 2024-07-18</p><h3>Evidences</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td><td><b>Detail</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:\">Positives Neugeborenenscreening</span></td><td><a href=\"Observation-mii-exa-seltene-observation-sma-screening.html\">Observation Spinal muscular atrophy newborn screening panel</a></td></tr></table><p><b>note</b>: </p><blockquote><div><p>Verdacht beim Neugeborenenscreening gestellt - SMN1 Exon 7 nicht nachweisbar</p>\n</div></blockquote></div></div>"
      },
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/condition-assertedDate",
        "valueDateTime" : "2024-07-18"
      }],
      "clinicalStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-clinical",
          "code" : "active"
        }]
      },
      "verificationStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-ver-status",
          "code" : "unconfirmed"
        }]
      },
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-category",
          "code" : "encounter-diagnosis"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "64383006",
          "display" : "Werdnig-Hoffmann disease"
        },
        {
          "system" : "http://human-phenotype-ontology.org",
          "code" : "HP:0007373",
          "display" : "Motor neuron atrophy"
        }],
        "text" : "Verdacht auf Spinale Muskelatrophie"
      },
      "subject" : {
        "reference" : "Patient/mii-exa-seltene-patient-sma-001"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-seltene-encounter-screening-001"
      },
      "recordedDate" : "2024-07-18",
      "evidence" : [{
        "code" : [{
          "text" : "Positives Neugeborenenscreening"
        }],
        "detail" : [{
          "reference" : "Observation/mii-exa-seltene-observation-sma-screening"
        }]
      }],
      "note" : [{
        "text" : "Verdacht beim Neugeborenenscreening gestellt - SMN1 Exon 7 nicht nachweisbar"
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "Condition"
    }
  },
  {
    "fullUrl" : "urn:uuid:7041e5af-feab-4650-af1b-e2051ba0a95a",
    "resource" : {
      "resourceType" : "Condition",
      "id" : "mii-exa-seltene-condition-sma-clinical",
      "meta" : {
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-clinical-diagnosis|2027.0.0-ballot.rc1"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"Condition_mii-exa-seltene-condition-sma-clinical\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Condition mii-exa-seltene-condition-sma-clinical</b></p><a name=\"mii-exa-seltene-condition-sma-clinical\"> </a><a name=\"hcmii-exa-seltene-condition-sma-clinical\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-mii-pr-seltene-clinical-diagnosis.html\">MII PR SE Clinical Diagnosis</a> version: 2027.0.0-ballot.rc1</p></div><p><b>Condition Asserted Date</b>: 2024-07-22</p><p><b>clinicalStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-clinical active}\">Active</span></p><p><b>verificationStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-ver-status confirmed}\">Confirmed</span></p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-category encounter-diagnosis}\">Encounter Diagnosis</span></p><p><b>code</b>: <span title=\"Codes:{http://fhir.de/CodeSystem/bfarm/icd-10-gm G12.0}, {http://snomed.info/sct 64383006}, {http://www.orpha.net 83330}, {http://human-phenotype-ontology.org HP:0007373}\">Infantile spinale Muskelatrophie, Typ I [Typ Werdnig-Hoffmann]</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-seltene-patient-sma-001.html\">Anonymous Patient Female, DoB: 2024-07-01 ( https://www.medizininformatik-initiative.de/fhir/sid/patient-id#SMA-2024-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-seltene-encounter-ambulant-001.html\">Encounter: status = finished; class = ambulatory (ActCode#AMB); type = Follow-up encounter; period = 2024-07-22 --&gt; 2024-07-22</a></p><p><b>onset</b>: 2024-07-01</p><p><b>recordedDate</b>: 2024-07-22</p><h3>Evidences</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td><td><b>Detail</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:\">Klinische Präsentation</span></td><td><a href=\"Observation-mii-exa-seltene-observation-troponin-001.html\">Observation Troponin T.cardiac [Mass/volume] in Serum or Plasma</a></td></tr></table><p><b>note</b>: </p><blockquote><div><p>Klinische Diagnose basierend auf typischer Präsentation: Neonatale Hypotonie, fehlende Muskeleigenreflexe, erhöhtes Troponin</p>\n</div></blockquote></div></div>"
      },
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/condition-assertedDate",
        "valueDateTime" : "2024-07-22"
      }],
      "clinicalStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-clinical",
          "code" : "active"
        }]
      },
      "verificationStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-ver-status",
          "code" : "confirmed"
        }]
      },
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-category",
          "code" : "encounter-diagnosis"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://fhir.de/CodeSystem/bfarm/icd-10-gm",
          "version" : "2024",
          "code" : "G12.0",
          "display" : "Infantile spinale Muskelatrophie, Typ I [Typ Werdnig-Hoffmann]"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "64383006",
          "display" : "Werdnig-Hoffmann disease"
        },
        {
          "system" : "http://www.orpha.net",
          "code" : "83330",
          "display" : "Proximal spinal muscular atrophy type 1"
        },
        {
          "system" : "http://human-phenotype-ontology.org",
          "code" : "HP:0007373",
          "display" : "Motor neuron atrophy"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-seltene-patient-sma-001"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-seltene-encounter-ambulant-001"
      },
      "onsetDateTime" : "2024-07-01",
      "recordedDate" : "2024-07-22",
      "evidence" : [{
        "code" : [{
          "text" : "Klinische Präsentation"
        }],
        "detail" : [{
          "reference" : "Observation/mii-exa-seltene-observation-troponin-001"
        }]
      }],
      "note" : [{
        "text" : "Klinische Diagnose basierend auf typischer Präsentation: Neonatale Hypotonie, fehlende Muskeleigenreflexe, erhöhtes Troponin"
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "Condition"
    }
  },
  {
    "fullUrl" : "urn:uuid:9596df71-0f1b-495f-bf1c-16708dc952bf",
    "resource" : {
      "resourceType" : "Condition",
      "id" : "mii-exa-seltene-condition-sma-genetic",
      "meta" : {
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-genetic-diagnosis|2027.0.0-ballot.rc1"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"Condition_mii-exa-seltene-condition-sma-genetic\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Condition mii-exa-seltene-condition-sma-genetic</b></p><a name=\"mii-exa-seltene-condition-sma-genetic\"> </a><a name=\"hcmii-exa-seltene-condition-sma-genetic\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-mii-pr-seltene-genetic-diagnosis.html\">MII PR SE Genetic Diagnosis</a> version: 2027.0.0-ballot.rc1</p></div><p><b>Condition Asserted Date</b>: 2024-07-26</p><p><b>clinicalStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-clinical active}\">Active</span></p><p><b>verificationStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-ver-status confirmed}\">Confirmed</span></p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 782964007}\">Genetic disease</span></p><p><b>code</b>: <span title=\"Codes:{http://omim.org 253300}, {http://snomed.info/sct 64383006}, {http://www.orpha.net 83330}\">Spinal muscular atrophy, type I</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-seltene-patient-sma-001.html\">Anonymous Patient Female, DoB: 2024-07-01 ( https://www.medizininformatik-initiative.de/fhir/sid/patient-id#SMA-2024-001)</a></p><p><b>onset</b>: 2024-07-01</p><p><b>recordedDate</b>: 2024-07-26</p><blockquote><p><b>evidence</b></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 106221001}\">Genetic finding</span></p><p><b>detail</b>: </p><ul><li><a href=\"Observation-mii-exa-seltene-variant-smn1-001.html\">Observation Genetic analysis master panel</a></li><li><a href=\"Observation-mii-exa-seltene-variant-smn2-001.html\">Observation Genetic analysis master panel</a></li></ul></blockquote><blockquote><p><b>evidence</b></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 405824009}\">Genetic test</span></p><p><b>detail</b>: <a href=\"DiagnosticReport-mii-exa-seltene-molgen-diagnostic-implication-sma.html\">Diagnostic Report for 'Genetic analysis report' for '-&gt;Max Mustermann (official) Male, DoB: 1990-01-01 ( http://test-krankenhaus.de/fhir/sid/patienten#12345)'</a></p></blockquote><p><b>note</b>: </p><blockquote><div><p>0 Kopien des SMN1-Gens, 2 Kopien des SMN2-Gens - krankheitsursächlich. Genetische Diagnose existiert parallel zur klinischen Diagnose.</p>\n</div></blockquote></div></div>"
      },
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/condition-assertedDate",
        "valueDateTime" : "2024-07-26"
      }],
      "clinicalStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-clinical",
          "code" : "active"
        }]
      },
      "verificationStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-ver-status",
          "code" : "confirmed"
        }]
      },
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "782964007",
          "display" : "Genetic disease"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://omim.org",
          "version" : "2024",
          "code" : "253300",
          "display" : "Spinal muscular atrophy, type I"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "64383006",
          "display" : "Werdnig-Hoffmann disease"
        },
        {
          "system" : "http://www.orpha.net",
          "code" : "83330",
          "display" : "Proximal spinal muscular atrophy type 1"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-seltene-patient-sma-001"
      },
      "onsetDateTime" : "2024-07-01",
      "recordedDate" : "2024-07-26",
      "evidence" : [{
        "code" : [{
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "106221001",
            "display" : "Genetic finding"
          }]
        }],
        "detail" : [{
          "reference" : "Observation/mii-exa-seltene-variant-smn1-001"
        },
        {
          "reference" : "Observation/mii-exa-seltene-variant-smn2-001"
        }]
      },
      {
        "code" : [{
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "405824009",
            "display" : "Genetic test"
          }]
        }],
        "detail" : [{
          "reference" : "DiagnosticReport/mii-exa-seltene-molgen-diagnostic-implication-sma"
        }]
      }],
      "note" : [{
        "text" : "0 Kopien des SMN1-Gens, 2 Kopien des SMN2-Gens - krankheitsursächlich. Genetische Diagnose existiert parallel zur klinischen Diagnose."
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "Condition"
    }
  },
  {
    "fullUrl" : "urn:uuid:00e23000-f21c-470d-8f71-1942f0f72efe",
    "resource" : {
      "resourceType" : "FamilyMemberHistory",
      "id" : "mii-exa-seltene-family-history-001",
      "meta" : {
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-familienanamnese|2027.0.0-ballot.rc1"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"FamilyMemberHistory_mii-exa-seltene-family-history-001\"> </a><p class=\"res-header-id\"><b>Generated Narrative: FamilyMemberHistory mii-exa-seltene-family-history-001</b></p><a name=\"mii-exa-seltene-family-history-001\"> </a><a name=\"hcmii-exa-seltene-family-history-001\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-mii-pr-seltene-familienanamnese.html\">MII PR SE Familienanamnese</a> version: 2027.0.0-ballot.rc1</p></div><p><b>MII_EX_Seltene_VonSEBetroffen</b>: <span title=\"Codes:{http://snomed.info/sct 261665006}\">Unknown</span></p><p><b>status</b>: Completed</p><p><b>patient</b>: <a href=\"Patient-mii-exa-seltene-patient-sma-001.html\">Anonymous Patient Female, DoB: 2024-07-01 ( https://www.medizininformatik-initiative.de/fhir/sid/patient-id#SMA-2024-001)</a></p><p><b>date</b>: 2024-07-22</p><p><b>relationship</b>: <span title=\"Codes:{http://snomed.info/sct 78652007}\">Great grandmother</span></p><h3>Conditions</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 129565002}\">Unbekannte Muskelerkrankung</span></td></tr></table></div></div>"
      },
      "extension" : [{
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-ex-seltene-von-se-betroffen",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "261665006",
            "display" : "Unknown"
          }]
        }
      }],
      "status" : "completed",
      "patient" : {
        "reference" : "Patient/mii-exa-seltene-patient-sma-001"
      },
      "date" : "2024-07-22",
      "relationship" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "78652007",
          "display" : "Great grandmother"
        }]
      },
      "condition" : [{
        "code" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "129565002",
            "display" : "Disorder of muscle"
          }],
          "text" : "Unbekannte Muskelerkrankung"
        }
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "FamilyMemberHistory"
    }
  },
  {
    "fullUrl" : "urn:uuid:07ff35a6-561b-4a3b-bfc0-be528e6ab5a4",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-seltene-observation-sma-screening",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"Observation_mii-exa-seltene-observation-sma-screening\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-seltene-observation-sma-screening</b></p><a name=\"mii-exa-seltene-observation-sma-screening\"> </a><a name=\"hcmii-exa-seltene-observation-sma-screening\"> </a><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 92005-8}\">Spinal muscular atrophy newborn screening panel</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-seltene-patient-sma-001.html\">Anonymous Patient Female, DoB: 2024-07-01 ( https://www.medizininformatik-initiative.de/fhir/sid/patient-id#SMA-2024-001)</a></p><p><b>effective</b>: 2024-07-18</p><p><b>value</b>: <span title=\"Codes:{http://snomed.info/sct 260373001}\">Detected</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation A}\">Abnormal</span></p><p><b>note</b>: </p><blockquote><div><p>Positives SMA-Screening. Konfirmatorische Diagnostik empfohlen.</p>\n</div></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 92004-1}\">Spinal muscular atrophy newborn screen interpretation</span></p><p><b>value</b>: <span title=\"Codes:\">Hinweis auf SMA - SMN1 Exon 7 Deletion nachgewiesen</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 92002-5}\">SMN1 gene [Cycle Threshold #] in DBS by NAA with probe detection</span></p><p><b>value</b>: 0 Ct<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code1 = '1')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation A}\">Abnormal</span></p></blockquote></div></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "92005-8",
          "display" : "Spinal muscular atrophy newborn screening panel"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-seltene-patient-sma-001"
      },
      "effectiveDateTime" : "2024-07-18",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "260373001",
          "display" : "Detected"
        }]
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "A",
          "display" : "Abnormal"
        }]
      }],
      "note" : [{
        "text" : "Positives SMA-Screening. Konfirmatorische Diagnostik empfohlen."
      }],
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "92004-1",
            "display" : "Spinal muscular atrophy newborn screen interpretation"
          }]
        },
        "valueCodeableConcept" : {
          "text" : "Hinweis auf SMA - SMN1 Exon 7 Deletion nachgewiesen"
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "92002-5",
            "display" : "SMN1 gene [Cycle Threshold #] in DBS by NAA with probe detection"
          }]
        },
        "valueQuantity" : {
          "value" : 0,
          "unit" : "Ct",
          "system" : "http://unitsofmeasure.org",
          "code" : "1"
        },
        "interpretation" : [{
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
            "code" : "A",
            "display" : "Abnormal"
          }]
        }]
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "Observation"
    }
  },
  {
    "fullUrl" : "urn:uuid:89231fbc-2218-499e-b3f5-c11368975c6e",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-seltene-variant-smn1-001",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"Observation_mii-exa-seltene-variant-smn1-001\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-seltene-variant-smn1-001</b></p><a name=\"mii-exa-seltene-variant-smn1-001\"> </a><a name=\"hcmii-exa-seltene-variant-smn1-001\"> </a><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 55233-1}\">Genetic analysis master panel</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-seltene-patient-sma-001.html\">Anonymous Patient Female, DoB: 2024-07-01 ( https://www.medizininformatik-initiative.de/fhir/sid/patient-id#SMA-2024-001)</a></p><p><b>effective</b>: 2024-07-26</p><p><b>value</b>: <span title=\"Codes:{http://snomed.info/sct 10828004}\">Positive</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation POS}\">Positive</span></p><p><b>note</b>: </p><blockquote><div><p>Homozygote Deletion des SMN1-Gens, krankheitsursächlich für SMA</p>\n</div></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 48018-6}\">Gene studied [ID]</span></p><p><b>value</b>: <span title=\"Codes:{http://www.genenames.org/geneId HGNC:11117}\">SMN1</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 62374-4}\">Human reference sequence assembly version</span></p><p><b>value</b>: <span title=\"Codes:\">GRCh38</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 53034-5}\">Allelic state</span></p><p><b>value</b>: <span title=\"Codes:{http://loinc.org LA6705-3}\">Homozygous</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:\">Copy Number</span></p><p><b>value</b>: 0 copies</p></blockquote></div></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "55233-1",
          "display" : "Genetic analysis master panel"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-seltene-patient-sma-001"
      },
      "effectiveDateTime" : "2024-07-26",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "10828004",
          "display" : "Positive"
        }]
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "POS",
          "display" : "Positive"
        }]
      }],
      "note" : [{
        "text" : "Homozygote Deletion des SMN1-Gens, krankheitsursächlich für SMA"
      }],
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "48018-6",
            "display" : "Gene studied [ID]"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://www.genenames.org/geneId",
            "code" : "HGNC:11117",
            "display" : "SMN1"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "62374-4",
            "display" : "Human reference sequence assembly version"
          }]
        },
        "valueCodeableConcept" : {
          "text" : "GRCh38"
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "53034-5",
            "display" : "Allelic state"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "LA6705-3",
            "display" : "Homozygous"
          }]
        }
      },
      {
        "code" : {
          "text" : "Copy Number"
        },
        "valueQuantity" : {
          "value" : 0,
          "unit" : "copies"
        }
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "Observation"
    }
  },
  {
    "fullUrl" : "urn:uuid:3325c12d-0646-433e-8e46-042168eccf92",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-seltene-variant-smn2-001",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"Observation_mii-exa-seltene-variant-smn2-001\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-seltene-variant-smn2-001</b></p><a name=\"mii-exa-seltene-variant-smn2-001\"> </a><a name=\"hcmii-exa-seltene-variant-smn2-001\"> </a><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 55233-1}\">Genetic analysis master panel</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-seltene-patient-sma-001.html\">Anonymous Patient Female, DoB: 2024-07-01 ( https://www.medizininformatik-initiative.de/fhir/sid/patient-id#SMA-2024-001)</a></p><p><b>effective</b>: 2024-07-26</p><p><b>note</b>: </p><blockquote><div><p>2 Kopien des SMN2-Gens, Modifikator des Phänotyps</p>\n</div></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 48018-6}\">Gene studied [ID]</span></p><p><b>value</b>: <span title=\"Codes:{http://www.genenames.org/geneId HGNC:11118}\">SMN2</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:\">Copy Number</span></p><p><b>value</b>: 2 copies</p></blockquote></div></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "55233-1",
          "display" : "Genetic analysis master panel"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-seltene-patient-sma-001"
      },
      "effectiveDateTime" : "2024-07-26",
      "note" : [{
        "text" : "2 Kopien des SMN2-Gens, Modifikator des Phänotyps"
      }],
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "48018-6",
            "display" : "Gene studied [ID]"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://www.genenames.org/geneId",
            "code" : "HGNC:11118",
            "display" : "SMN2"
          }]
        }
      },
      {
        "code" : {
          "text" : "Copy Number"
        },
        "valueQuantity" : {
          "value" : 2,
          "unit" : "copies"
        }
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "Observation"
    }
  },
  {
    "fullUrl" : "urn:uuid:127dc51a-19ad-44ff-bf75-b1804d232109",
    "resource" : {
      "resourceType" : "Procedure",
      "id" : "mii-exa-seltene-procedure-gentherapy-001",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"Procedure_mii-exa-seltene-procedure-gentherapy-001\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Procedure mii-exa-seltene-procedure-gentherapy-001</b></p><a name=\"mii-exa-seltene-procedure-gentherapy-001\"> </a><a name=\"hcmii-exa-seltene-procedure-gentherapy-001\"> </a><p><b>status</b>: Completed</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 277132007}\">Therapeutic procedure</span></p><p><b>code</b>: <span title=\"Codes:{http://fdasis.nlm.nih.gov MLU3LU3EVV}, {http://snomed.info/sct 788110002}\">Gentherapie mit Onasemnogene abeparvovec (Zolgensma)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-seltene-patient-sma-001.html\">Anonymous Patient Female, DoB: 2024-07-01 ( https://www.medizininformatik-initiative.de/fhir/sid/patient-id#SMA-2024-001)</a></p><p><b>performed</b>: 2024-07-29</p><p><b>reasonReference</b>: <a href=\"Condition-mii-exa-seltene-condition-sma-genetic.html\">Condition Spinal muscular atrophy, type I</a></p><p><b>note</b>: </p><blockquote><div><p>Gentherapeutikum ohne Komplikationen verabreicht, vorherige Gabe von Prednisolon</p>\n</div></blockquote></div></div>"
      },
      "status" : "completed",
      "category" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "277132007",
          "display" : "Therapeutic procedure"
        }]
      },
      "code" : {
        "coding" : [{
          "system" : "http://fdasis.nlm.nih.gov",
          "code" : "MLU3LU3EVV",
          "display" : "ONASEMNOGENE ABEPARVOVEC"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "788110002",
          "display" : "Onasemnogene abeparvovec"
        }],
        "text" : "Gentherapie mit Onasemnogene abeparvovec (Zolgensma)"
      },
      "subject" : {
        "reference" : "Patient/mii-exa-seltene-patient-sma-001"
      },
      "performedDateTime" : "2024-07-29",
      "reasonReference" : [{
        "reference" : "Condition/mii-exa-seltene-condition-sma-genetic"
      }],
      "note" : [{
        "text" : "Gentherapeutikum ohne Komplikationen verabreicht, vorherige Gabe von Prednisolon"
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "Procedure"
    }
  },
  {
    "fullUrl" : "urn:uuid:ccdcbdd3-8153-4ef2-8d76-1ee0f681328b",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-seltene-observation-alt-001",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"Observation_mii-exa-seltene-observation-alt-001\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-seltene-observation-alt-001</b></p><a name=\"mii-exa-seltene-observation-alt-001\"> </a><a name=\"hcmii-exa-seltene-observation-alt-001\"> </a><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 1742-6}\">Alanine aminotransferase [Enzymatic activity/volume] in Serum or Plasma</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-seltene-patient-sma-001.html\">Anonymous Patient Female, DoB: 2024-07-01 ( https://www.medizininformatik-initiative.de/fhir/sid/patient-id#SMA-2024-001)</a></p><p><b>effective</b>: 2024-07-29</p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation N}\">Normal</span></p><p><b>note</b>: </p><blockquote><div><p>Normwertig post-therapeutisch</p>\n</div></blockquote></div></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "1742-6",
          "display" : "Alanine aminotransferase [Enzymatic activity/volume] in Serum or Plasma"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-seltene-patient-sma-001"
      },
      "effectiveDateTime" : "2024-07-29",
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "N",
          "display" : "Normal"
        }]
      }],
      "note" : [{
        "text" : "Normwertig post-therapeutisch"
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "Observation"
    }
  },
  {
    "fullUrl" : "urn:uuid:bb92ee35-b577-42a8-bf9a-b51cbe5debae",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-seltene-observation-ast-001",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"Observation_mii-exa-seltene-observation-ast-001\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-seltene-observation-ast-001</b></p><a name=\"mii-exa-seltene-observation-ast-001\"> </a><a name=\"hcmii-exa-seltene-observation-ast-001\"> </a><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 1920-8}\">Aspartate aminotransferase [Enzymatic activity/volume] in Serum or Plasma</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-seltene-patient-sma-001.html\">Anonymous Patient Female, DoB: 2024-07-01 ( https://www.medizininformatik-initiative.de/fhir/sid/patient-id#SMA-2024-001)</a></p><p><b>effective</b>: 2024-07-29</p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation N}\">Normal</span></p><p><b>note</b>: </p><blockquote><div><p>Normwertig post-therapeutisch</p>\n</div></blockquote></div></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "1920-8",
          "display" : "Aspartate aminotransferase [Enzymatic activity/volume] in Serum or Plasma"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-seltene-patient-sma-001"
      },
      "effectiveDateTime" : "2024-07-29",
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "N",
          "display" : "Normal"
        }]
      }],
      "note" : [{
        "text" : "Normwertig post-therapeutisch"
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "Observation"
    }
  },
  {
    "fullUrl" : "urn:uuid:38b52a28-bfa6-451f-8dad-9d0b8a8466bc",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-seltene-observation-plt-001",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"Observation_mii-exa-seltene-observation-plt-001\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-seltene-observation-plt-001</b></p><a name=\"mii-exa-seltene-observation-plt-001\"> </a><a name=\"hcmii-exa-seltene-observation-plt-001\"> </a><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 777-3}\">Platelets [#/volume] in Blood by Automated count</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-seltene-patient-sma-001.html\">Anonymous Patient Female, DoB: 2024-07-01 ( https://www.medizininformatik-initiative.de/fhir/sid/patient-id#SMA-2024-001)</a></p><p><b>effective</b>: 2024-07-29</p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation N}\">Normal</span></p><p><b>note</b>: </p><blockquote><div><p>Normwertig post-therapeutisch</p>\n</div></blockquote></div></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "777-3",
          "display" : "Platelets [#/volume] in Blood by Automated count"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-seltene-patient-sma-001"
      },
      "effectiveDateTime" : "2024-07-29",
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "N",
          "display" : "Normal"
        }]
      }],
      "note" : [{
        "text" : "Normwertig post-therapeutisch"
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "Observation"
    }
  },
  {
    "fullUrl" : "urn:uuid:ab5b69cf-4eae-4aa3-8ce4-5b5eb1a4a46a",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-seltene-observation-troponin-001",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"Observation_mii-exa-seltene-observation-troponin-001\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-seltene-observation-troponin-001</b></p><a name=\"mii-exa-seltene-observation-troponin-001\"> </a><a name=\"hcmii-exa-seltene-observation-troponin-001\"> </a><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 6598-7}\">Troponin T.cardiac [Mass/volume] in Serum or Plasma</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-seltene-patient-sma-001.html\">Anonymous Patient Female, DoB: 2024-07-01 ( https://www.medizininformatik-initiative.de/fhir/sid/patient-id#SMA-2024-001)</a></p><p><b>effective</b>: 2024-07-22</p><p><b>value</b>: 92 ng/L<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeng/L = 'ng/L')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation H}\">High</span></p></div></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "6598-7",
          "display" : "Troponin T.cardiac [Mass/volume] in Serum or Plasma"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-seltene-patient-sma-001"
      },
      "effectiveDateTime" : "2024-07-22",
      "valueQuantity" : {
        "value" : 92,
        "unit" : "ng/L",
        "system" : "http://unitsofmeasure.org",
        "code" : "ng/L"
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "H",
          "display" : "High"
        }]
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "Observation"
    }
  },
  {
    "fullUrl" : "urn:uuid:23b8775e-4704-4037-930e-68d1628cf0b8",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-seltene-observation-troponin-002",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"Observation_mii-exa-seltene-observation-troponin-002\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-seltene-observation-troponin-002</b></p><a name=\"mii-exa-seltene-observation-troponin-002\"> </a><a name=\"hcmii-exa-seltene-observation-troponin-002\"> </a><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 6598-7}\">Troponin T.cardiac [Mass/volume] in Serum or Plasma</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-seltene-patient-sma-001.html\">Anonymous Patient Female, DoB: 2024-07-01 ( https://www.medizininformatik-initiative.de/fhir/sid/patient-id#SMA-2024-001)</a></p><p><b>effective</b>: 2024-07-28</p><p><b>value</b>: 58 ng/L<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeng/L = 'ng/L')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation H}\">High</span></p></div></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "6598-7",
          "display" : "Troponin T.cardiac [Mass/volume] in Serum or Plasma"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-seltene-patient-sma-001"
      },
      "effectiveDateTime" : "2024-07-28",
      "valueQuantity" : {
        "value" : 58,
        "unit" : "ng/L",
        "system" : "http://unitsofmeasure.org",
        "code" : "ng/L"
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "H",
          "display" : "High"
        }]
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "Observation"
    }
  },
  {
    "fullUrl" : "urn:uuid:7d919637-556d-441d-8145-706eb3543fa3",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-seltene-observation-troponin-003",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"Observation_mii-exa-seltene-observation-troponin-003\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-seltene-observation-troponin-003</b></p><a name=\"mii-exa-seltene-observation-troponin-003\"> </a><a name=\"hcmii-exa-seltene-observation-troponin-003\"> </a><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 6598-7}\">Troponin T.cardiac [Mass/volume] in Serum or Plasma</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-seltene-patient-sma-001.html\">Anonymous Patient Female, DoB: 2024-07-01 ( https://www.medizininformatik-initiative.de/fhir/sid/patient-id#SMA-2024-001)</a></p><p><b>effective</b>: 2024-08-01</p><p><b>value</b>: 57 ng/L<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeng/L = 'ng/L')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation H}\">High</span></p></div></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "6598-7",
          "display" : "Troponin T.cardiac [Mass/volume] in Serum or Plasma"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-seltene-patient-sma-001"
      },
      "effectiveDateTime" : "2024-08-01",
      "valueQuantity" : {
        "value" : 57,
        "unit" : "ng/L",
        "system" : "http://unitsofmeasure.org",
        "code" : "ng/L"
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "H",
          "display" : "High"
        }]
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "Observation"
    }
  },
  {
    "fullUrl" : "urn:uuid:0ccc9861-03d4-403b-a650-a9f24d64a615",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-seltene-observation-troponin-004",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"Observation_mii-exa-seltene-observation-troponin-004\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-seltene-observation-troponin-004</b></p><a name=\"mii-exa-seltene-observation-troponin-004\"> </a><a name=\"hcmii-exa-seltene-observation-troponin-004\"> </a><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 6598-7}\">Troponin T.cardiac [Mass/volume] in Serum or Plasma</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-seltene-patient-sma-001.html\">Anonymous Patient Female, DoB: 2024-07-01 ( https://www.medizininformatik-initiative.de/fhir/sid/patient-id#SMA-2024-001)</a></p><p><b>effective</b>: 2024-08-12</p><p><b>value</b>: 106 ng/L<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeng/L = 'ng/L')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation H}\">High</span></p><p><b>note</b>: </p><blockquote><div><p>Troponin T weiter erhöht, bereits prä-therapeutisch erhöht</p>\n</div></blockquote></div></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "6598-7",
          "display" : "Troponin T.cardiac [Mass/volume] in Serum or Plasma"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-seltene-patient-sma-001"
      },
      "effectiveDateTime" : "2024-08-12",
      "valueQuantity" : {
        "value" : 106,
        "unit" : "ng/L",
        "system" : "http://unitsofmeasure.org",
        "code" : "ng/L"
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "H",
          "display" : "High"
        }]
      }],
      "note" : [{
        "text" : "Troponin T weiter erhöht, bereits prä-therapeutisch erhöht"
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "Observation"
    }
  },
  {
    "fullUrl" : "urn:uuid:81c1e902-ea19-4d32-adbf-3ee234509cf6",
    "resource" : {
      "resourceType" : "ClinicalImpression",
      "id" : "mii-exa-seltene-clinical-impression-erstvorstellung",
      "meta" : {
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-clinical-impression|2027.0.0-ballot.rc1"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"ClinicalImpression_mii-exa-seltene-clinical-impression-erstvorstellung\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ClinicalImpression mii-exa-seltene-clinical-impression-erstvorstellung</b></p><a name=\"mii-exa-seltene-clinical-impression-erstvorstellung\"> </a><a name=\"hcmii-exa-seltene-clinical-impression-erstvorstellung\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-mii-pr-seltene-clinical-impression.html\">MII Profile SE Clinical Impression</a> version: 2027.0.0-ballot.rc1</p></div><p><b>status</b>: Completed</p><p><b>subject</b>: <a href=\"Patient-mii-exa-seltene-patient-sma-001.html\">Anonymous Patient Female, DoB: 2024-07-01 ( https://www.medizininformatik-initiative.de/fhir/sid/patient-id#SMA-2024-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-seltene-encounter-ambulant-001.html\">Encounter: status = finished; class = ambulatory (ActCode#AMB); type = Follow-up encounter; period = 2024-07-22 --&gt; 2024-07-22</a></p><p><b>effective</b>: 2024-07-22</p><p><b>date</b>: 2024-07-22</p><p><b>problem</b>: <a href=\"Condition-mii-exa-seltene-condition-sma-suspected.html\">Condition Werdnig-Hoffmann disease</a></p><blockquote><p><b>investigation</b></p><p><b>code</b>: <span title=\"Codes:\">Familienanamnese</span></p><p><b>item</b>: <a href=\"FamilyMemberHistory-mii-exa-seltene-family-history-001.html\">FamilyMemberHistory: extension = Unknown; status = completed; date = 2024-07-22; relationship = Great grandmother</a></p></blockquote><blockquote><p><b>investigation</b></p><p><b>code</b>: <span title=\"Codes:\">Labordiagnostik</span></p><p><b>item</b>: <a href=\"Observation-mii-exa-seltene-observation-troponin-001.html\">Observation Troponin T.cardiac [Mass/volume] in Serum or Plasma</a></p></blockquote><p><b>summary</b>: Neugeborenes mit V.a. SMA aus Neugeborenenscreening. Familienanamnese zeigt unklare Muskelerkrankung der Urgroßmutter. Troponin T bereits erhöht (92 ng/l).</p><blockquote><p><b>finding</b></p><p><b>itemReference</b>: <a href=\"Condition-mii-exa-seltene-condition-sma-clinical.html\">Condition Infantile spinale Muskelatrophie, Typ I [Typ Werdnig-Hoffmann]</a></p></blockquote><blockquote><p><b>finding</b></p><p><b>itemReference</b>: <a href=\"Condition-mii-exa-seltene-condition-sma-genetic.html\">Condition Spinal muscular atrophy, type I</a></p></blockquote><blockquote><p><b>finding</b></p><p><b>itemCodeableConcept</b>: <span title=\"Codes:{http://snomed.info/sct 1363512008}\">Troponin above reference range</span></p><p><b>itemReference</b>: <a href=\"Observation-mii-exa-seltene-observation-troponin-001.html\">Observation Troponin T.cardiac [Mass/volume] in Serum or Plasma</a></p></blockquote><p><b>prognosisCodeableConcept</b>: <span title=\"Codes:{http://snomed.info/sct 67334001}\">Guarded prognosis</span></p><p><b>note</b>: , </p><blockquote><div><p>Klinische Untersuchung gemäß SMA-Diagnoseprotokoll. Blutentnahme für Genetik veranlasst.</p>\n</div></blockquote><blockquote><div><p>Klinisches Bild vereinbar mit SMA Typ 1. Molekulargenetische Bestätigung ausstehend. Eltern über Therapieoptionen informiert.</p>\n</div></blockquote></div></div>"
      },
      "status" : "completed",
      "subject" : {
        "reference" : "Patient/mii-exa-seltene-patient-sma-001"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-seltene-encounter-ambulant-001"
      },
      "effectiveDateTime" : "2024-07-22",
      "date" : "2024-07-22",
      "problem" : [{
        "reference" : "Condition/mii-exa-seltene-condition-sma-suspected"
      }],
      "investigation" : [{
        "code" : {
          "text" : "Familienanamnese"
        },
        "item" : [{
          "reference" : "FamilyMemberHistory/mii-exa-seltene-family-history-001"
        }]
      },
      {
        "code" : {
          "text" : "Labordiagnostik"
        },
        "item" : [{
          "reference" : "Observation/mii-exa-seltene-observation-troponin-001"
        }]
      }],
      "summary" : "Neugeborenes mit V.a. SMA aus Neugeborenenscreening. Familienanamnese zeigt unklare Muskelerkrankung der Urgroßmutter. Troponin T bereits erhöht (92 ng/l).",
      "finding" : [{
        "itemReference" : {
          "reference" : "Condition/mii-exa-seltene-condition-sma-clinical"
        }
      },
      {
        "itemReference" : {
          "reference" : "Condition/mii-exa-seltene-condition-sma-genetic"
        }
      },
      {
        "itemCodeableConcept" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "1363512008",
            "display" : "Troponin above reference range"
          }]
        },
        "itemReference" : {
          "reference" : "Observation/mii-exa-seltene-observation-troponin-001"
        }
      }],
      "prognosisCodeableConcept" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "67334001",
          "display" : "Guarded prognosis"
        }]
      }],
      "note" : [{
        "text" : "Klinische Untersuchung gemäß SMA-Diagnoseprotokoll. Blutentnahme für Genetik veranlasst."
      },
      {
        "text" : "Klinisches Bild vereinbar mit SMA Typ 1. Molekulargenetische Bestätigung ausstehend. Eltern über Therapieoptionen informiert."
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "ClinicalImpression"
    }
  },
  {
    "fullUrl" : "urn:uuid:b764f4a2-50c0-4624-ad49-8eb9405aaf9d",
    "resource" : {
      "resourceType" : "ClinicalImpression",
      "id" : "mii-exa-seltene-clinical-impression-nachsorge",
      "meta" : {
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-seltene/StructureDefinition/mii-pr-seltene-clinical-impression|2027.0.0-ballot.rc1"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"ClinicalImpression_mii-exa-seltene-clinical-impression-nachsorge\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ClinicalImpression mii-exa-seltene-clinical-impression-nachsorge</b></p><a name=\"mii-exa-seltene-clinical-impression-nachsorge\"> </a><a name=\"hcmii-exa-seltene-clinical-impression-nachsorge\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-mii-pr-seltene-clinical-impression.html\">MII Profile SE Clinical Impression</a> version: 2027.0.0-ballot.rc1</p></div><p><b>status</b>: Completed</p><p><b>subject</b>: <a href=\"Patient-mii-exa-seltene-patient-sma-001.html\">Anonymous Patient Female, DoB: 2024-07-01 ( https://www.medizininformatik-initiative.de/fhir/sid/patient-id#SMA-2024-001)</a></p><p><b>encounter</b>: <a href=\"Encounter-mii-exa-seltene-encounter-nachsorge-001.html\">Encounter: status = finished; class = ambulatory (ActCode#AMB); type = Follow-up encounter; period = 2024-08-12 --&gt; 2024-08-12</a></p><p><b>effective</b>: 2024-08-12</p><p><b>date</b>: 2024-08-12</p><p><b>previous</b>: <a href=\"ClinicalImpression-mii-exa-seltene-clinical-impression-erstvorstellung.html\">ClinicalImpression: status = completed; effective[x] = 2024-07-22; date = 2024-07-22; summary = Neugeborenes mit V.a. SMA aus Neugeborenenscreening. Familienanamnese zeigt unklare Muskelerkrankung der Urgroßmutter. Troponin T bereits erhöht (92 ng/l).; prognosisCodeableConcept = Guarded prognosis; note = Klinische Untersuchung gemäß SMA-Diagnoseprotokoll. Blutentnahme für Genetik veranlasst.,Klinisches Bild vereinbar mit SMA Typ 1. Molekulargenetische Bestätigung ausstehend. Eltern über Therapieoptionen informiert.</a></p><p><b>problem</b>: </p><ul><li><a href=\"Condition-mii-exa-seltene-condition-sma-clinical.html\">Condition Infantile spinale Muskelatrophie, Typ I [Typ Werdnig-Hoffmann]</a></li><li><a href=\"Condition-mii-exa-seltene-condition-sma-genetic.html\">Condition Spinal muscular atrophy, type I</a></li></ul><p><b>summary</b>: Erste Nachsorge 14 Tage nach Gentherapie. Klinisch stabil. Troponin T weiter erhöht (106 ng/l), war jedoch bereits prätherapeutisch erhöht.</p><blockquote><p><b>finding</b></p><p><b>itemCodeableConcept</b>: <span title=\"Codes:{http://snomed.info/sct 1363512008}\">Troponin above reference range</span></p><p><b>itemReference</b>: <a href=\"Observation-mii-exa-seltene-observation-troponin-004.html\">Observation Troponin T.cardiac [Mass/volume] in Serum or Plasma</a></p><p><b>basis</b>: Troponin-Verlauf: 22.07: 92 ng/l, 28.07: 58 ng/l, 01.08: 57 ng/l, 12.08: 106 ng/l</p></blockquote><blockquote><p><b>finding</b></p><p><b>itemCodeableConcept</b>: <span title=\"Codes:{http://snomed.info/sct 166645004}\">Alanine aminotransferase level within reference range</span></p><p><b>basis</b>: ALT normwertig</p></blockquote><blockquote><p><b>finding</b></p><p><b>itemCodeableConcept</b>: <span title=\"Codes:{http://snomed.info/sct 166667003}\">Aspartate aminotransferase/serum glutamic oxaloacetic transaminase level within reference range</span></p><p><b>basis</b>: AST normwertig</p></blockquote><blockquote><p><b>finding</b></p><p><b>itemCodeableConcept</b>: <span title=\"Codes:{http://snomed.info/sct 165555003}\">Platelet count normal</span></p><p><b>basis</b>: Thrombozytenzahl normwertig</p></blockquote><p><b>prognosisCodeableConcept</b>: <span title=\"Codes:{http://snomed.info/sct 67334001}\">Guarded prognosis</span></p><p><b>note</b>: , </p><blockquote><div><p>Standardisierte Nachsorgeuntersuchung nach Gentherapie gemäß Zentrumsprotokoll</p>\n</div></blockquote><blockquote><div><p>Troponin-Erhöhung präexistent, nicht therapieassoziiert. Gentherapie gut vertragen. Weiterführung der Prednisolon-Therapie. Nächste Kontrolle in 4 Wochen.</p>\n</div></blockquote></div></div>"
      },
      "status" : "completed",
      "subject" : {
        "reference" : "Patient/mii-exa-seltene-patient-sma-001"
      },
      "encounter" : {
        "reference" : "Encounter/mii-exa-seltene-encounter-nachsorge-001"
      },
      "effectiveDateTime" : "2024-08-12",
      "date" : "2024-08-12",
      "previous" : {
        "reference" : "ClinicalImpression/mii-exa-seltene-clinical-impression-erstvorstellung"
      },
      "problem" : [{
        "reference" : "Condition/mii-exa-seltene-condition-sma-clinical"
      },
      {
        "reference" : "Condition/mii-exa-seltene-condition-sma-genetic"
      }],
      "summary" : "Erste Nachsorge 14 Tage nach Gentherapie. Klinisch stabil. Troponin T weiter erhöht (106 ng/l), war jedoch bereits prätherapeutisch erhöht.",
      "finding" : [{
        "itemCodeableConcept" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "1363512008",
            "display" : "Troponin above reference range"
          }]
        },
        "itemReference" : {
          "reference" : "Observation/mii-exa-seltene-observation-troponin-004"
        },
        "basis" : "Troponin-Verlauf: 22.07: 92 ng/l, 28.07: 58 ng/l, 01.08: 57 ng/l, 12.08: 106 ng/l"
      },
      {
        "itemCodeableConcept" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "166645004",
            "display" : "Alanine aminotransferase level within reference range"
          }]
        },
        "basis" : "ALT normwertig"
      },
      {
        "itemCodeableConcept" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "166667003",
            "display" : "Aspartate aminotransferase/serum glutamic oxaloacetic transaminase level within reference range"
          }]
        },
        "basis" : "AST normwertig"
      },
      {
        "itemCodeableConcept" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "165555003",
            "display" : "Platelet count normal"
          }]
        },
        "basis" : "Thrombozytenzahl normwertig"
      }],
      "prognosisCodeableConcept" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "67334001",
          "display" : "Guarded prognosis"
        }]
      }],
      "note" : [{
        "text" : "Standardisierte Nachsorgeuntersuchung nach Gentherapie gemäß Zentrumsprotokoll"
      },
      {
        "text" : "Troponin-Erhöhung präexistent, nicht therapieassoziiert. Gentherapie gut vertragen. Weiterführung der Prednisolon-Therapie. Nächste Kontrolle in 4 Wochen."
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "ClinicalImpression"
    }
  },
  {
    "fullUrl" : "urn:uuid:8320638f-eca2-4586-b173-bd0c49d9ae9d",
    "resource" : {
      "resourceType" : "Encounter",
      "id" : "mii-exa-seltene-encounter-screening-001",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"Encounter_mii-exa-seltene-encounter-screening-001\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Encounter mii-exa-seltene-encounter-screening-001</b></p><a name=\"mii-exa-seltene-encounter-screening-001\"> </a><a name=\"hcmii-exa-seltene-encounter-screening-001\"> </a><p><b>status</b>: Finished</p><p><b>class</b>: <a href=\"http://terminology.hl7.org/7.3.0/CodeSystem-v3-ActCode.html#v3-ActCode-AMB\">ActCode: AMB</a> (ambulatory)</p><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 60151004}\">Neonatal screening (procedure)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-seltene-patient-sma-001.html\">Anonymous Patient Female, DoB: 2024-07-01 ( https://www.medizininformatik-initiative.de/fhir/sid/patient-id#SMA-2024-001)</a></p><p><b>period</b>: 2024-07-18 --&gt; 2024-07-18</p><p><b>reasonCode</b>: <span title=\"Codes:\">Neugeborenenscreening</span></p></div></div>"
      },
      "status" : "finished",
      "class" : {
        "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
        "code" : "AMB",
        "display" : "ambulatory"
      },
      "type" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "60151004",
          "display" : "Neonatal screening (procedure)"
        }]
      }],
      "subject" : {
        "reference" : "Patient/mii-exa-seltene-patient-sma-001"
      },
      "period" : {
        "start" : "2024-07-18",
        "end" : "2024-07-18"
      },
      "reasonCode" : [{
        "text" : "Neugeborenenscreening"
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "Encounter"
    }
  },
  {
    "fullUrl" : "urn:uuid:98afd481-d1d6-4c2e-9d1c-51c651964e5f",
    "resource" : {
      "resourceType" : "Encounter",
      "id" : "mii-exa-seltene-encounter-ambulant-001",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"Encounter_mii-exa-seltene-encounter-ambulant-001\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Encounter mii-exa-seltene-encounter-ambulant-001</b></p><a name=\"mii-exa-seltene-encounter-ambulant-001\"> </a><a name=\"hcmii-exa-seltene-encounter-ambulant-001\"> </a><p><b>status</b>: Finished</p><p><b>class</b>: <a href=\"http://terminology.hl7.org/7.3.0/CodeSystem-v3-ActCode.html#v3-ActCode-AMB\">ActCode: AMB</a> (ambulatory)</p><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 390906007}\">Follow-up encounter</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-seltene-patient-sma-001.html\">Anonymous Patient Female, DoB: 2024-07-01 ( https://www.medizininformatik-initiative.de/fhir/sid/patient-id#SMA-2024-001)</a></p><p><b>period</b>: 2024-07-22 --&gt; 2024-07-22</p><h3>Diagnoses</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Condition</b></td><td><b>Use</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Condition-mii-exa-seltene-condition-sma-clinical.html\">Condition Infantile spinale Muskelatrophie, Typ I [Typ Werdnig-Hoffmann]</a></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/diagnosis-role AD}\">Admission diagnosis</span></td></tr></table></div></div>"
      },
      "status" : "finished",
      "class" : {
        "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
        "code" : "AMB",
        "display" : "ambulatory"
      },
      "type" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "390906007",
          "display" : "Follow-up encounter"
        }]
      }],
      "subject" : {
        "reference" : "Patient/mii-exa-seltene-patient-sma-001"
      },
      "period" : {
        "start" : "2024-07-22",
        "end" : "2024-07-22"
      },
      "diagnosis" : [{
        "condition" : {
          "reference" : "Condition/mii-exa-seltene-condition-sma-clinical"
        },
        "use" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/diagnosis-role",
            "code" : "AD",
            "display" : "Admission diagnosis"
          }]
        }
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "Encounter"
    }
  },
  {
    "fullUrl" : "urn:uuid:bdb5bd40-064b-4b79-aab6-8d9cc9db4873",
    "resource" : {
      "resourceType" : "Encounter",
      "id" : "mii-exa-seltene-encounter-stationaer-001",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"Encounter_mii-exa-seltene-encounter-stationaer-001\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Encounter mii-exa-seltene-encounter-stationaer-001</b></p><a name=\"mii-exa-seltene-encounter-stationaer-001\"> </a><a name=\"hcmii-exa-seltene-encounter-stationaer-001\"> </a><p><b>status</b>: Finished</p><p><b>class</b>: <a href=\"http://terminology.hl7.org/7.3.0/CodeSystem-v3-ActCode.html#v3-ActCode-IMP\">ActCode: IMP</a> (inpatient encounter)</p><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 32485007}\">Hospital admission</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-seltene-patient-sma-001.html\">Anonymous Patient Female, DoB: 2024-07-01 ( https://www.medizininformatik-initiative.de/fhir/sid/patient-id#SMA-2024-001)</a></p><p><b>period</b>: 2024-07-29 --&gt; 2024-07-30</p><h3>Diagnoses</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Condition</b></td><td><b>Use</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Condition-mii-exa-seltene-condition-sma-genetic.html\">Condition Spinal muscular atrophy, type I</a></td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/diagnosis-role CC}\">Chief complaint</span></td></tr></table></div></div>"
      },
      "status" : "finished",
      "class" : {
        "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
        "code" : "IMP",
        "display" : "inpatient encounter"
      },
      "type" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "32485007",
          "display" : "Hospital admission"
        }]
      }],
      "subject" : {
        "reference" : "Patient/mii-exa-seltene-patient-sma-001"
      },
      "period" : {
        "start" : "2024-07-29",
        "end" : "2024-07-30"
      },
      "diagnosis" : [{
        "condition" : {
          "reference" : "Condition/mii-exa-seltene-condition-sma-genetic"
        },
        "use" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/diagnosis-role",
            "code" : "CC",
            "display" : "Chief complaint"
          }]
        }
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "Encounter"
    }
  },
  {
    "fullUrl" : "urn:uuid:f8e29cb1-a8a9-4d56-ac0e-65fca096f860",
    "resource" : {
      "resourceType" : "Encounter",
      "id" : "mii-exa-seltene-encounter-nachsorge-001",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"Encounter_mii-exa-seltene-encounter-nachsorge-001\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Encounter mii-exa-seltene-encounter-nachsorge-001</b></p><a name=\"mii-exa-seltene-encounter-nachsorge-001\"> </a><a name=\"hcmii-exa-seltene-encounter-nachsorge-001\"> </a><p><b>status</b>: Finished</p><p><b>class</b>: <a href=\"http://terminology.hl7.org/7.3.0/CodeSystem-v3-ActCode.html#v3-ActCode-AMB\">ActCode: AMB</a> (ambulatory)</p><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 390906007}\">Follow-up encounter</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-seltene-patient-sma-001.html\">Anonymous Patient Female, DoB: 2024-07-01 ( https://www.medizininformatik-initiative.de/fhir/sid/patient-id#SMA-2024-001)</a></p><p><b>period</b>: 2024-08-12 --&gt; 2024-08-12</p><h3>Diagnoses</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Condition</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Condition-mii-exa-seltene-condition-sma-genetic.html\">Condition Spinal muscular atrophy, type I</a></td></tr></table></div></div>"
      },
      "status" : "finished",
      "class" : {
        "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
        "code" : "AMB",
        "display" : "ambulatory"
      },
      "type" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "390906007",
          "display" : "Follow-up encounter"
        }]
      }],
      "subject" : {
        "reference" : "Patient/mii-exa-seltene-patient-sma-001"
      },
      "period" : {
        "start" : "2024-08-12",
        "end" : "2024-08-12"
      },
      "diagnosis" : [{
        "condition" : {
          "reference" : "Condition/mii-exa-seltene-condition-sma-genetic"
        }
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "Encounter"
    }
  }]
}

```
